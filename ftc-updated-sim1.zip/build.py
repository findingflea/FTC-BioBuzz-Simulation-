import pathlib, sys
R = pathlib.Path(__file__).parent
js = ['src/parser.js','src/emitter.js','src/runtime.js','src/sdk.js','src/sim.js','src/game.js','src/examples.js','ui/scene.js','ui/gamepad.js','ui/app.js','ui/match.js']
css = (R/'ui/style.css').read_text()
body = (R/'ui/body.html').read_text()
scripts = '\n'.join((R/p).read_text().replace('</script', '<\\/script') for p in js)
THREE_CDN = 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js'
def page(three_src):
    return f'''<title>FTC Field Sim</title>
<meta name="claude:viewport-fit-sides" content="cover">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600&family=Barlow+Semi+Condensed:wght@600;700&family=JetBrains+Mono:wght@400;600&display=swap">
<style>
{css}
</style>
{body}
<script src="{three_src}"></script>
<script>
{scripts}
</script>
'''
(R/'dist/ftc-field-sim.html').write_text(page(THREE_CDN))
(R/'dist/test.html').write_text('<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"></head><body>' + page('../tests/three-stub.js').replace('<link rel="stylesheet" href="https://fonts.googleapis.com', '<link rel="x-stylesheet" href="https://fonts.googleapis.com') + '</body></html>')
print('built', (R/'dist/ftc-field-sim.html').stat().st_size, 'bytes')

(R/'dist/test3d.html').write_text('<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"></head><body>' + page('../vendor/three.min.js').replace('<link rel="stylesheet" href="https://fonts.googleapis.com', '<link rel="x-stylesheet" href="https://fonts.googleapis.com') + '</body></html>')
