// Minimal stand-in for three.js so the UI can be exercised headlessly (no rendering).
(function(){
  class V3 { constructor(x=0,y=0,z=0){this.x=x;this.y=y;this.z=z;} set(x,y,z){this.x=x;this.y=y;this.z=z;return this;} copy(v){return this.set(v.x,v.y,v.z);} lerp(v,a){this.x+=(v.x-this.x)*a;this.y+=(v.y-this.y)*a;this.z+=(v.z-this.z)*a;return this;} addScaledVector(v,s){this.x+=v.x*s;this.y+=v.y*s;this.z+=v.z*s;return this;} clone(){return new V3(this.x,this.y,this.z);} subVectors(a,b){return this.set(a.x-b.x,a.y-b.y,a.z-b.z);} length(){return Math.hypot(this.x,this.y,this.z);} normalize(){const l=this.length()||1;return this.set(this.x/l,this.y/l,this.z/l);} }
  class E { constructor(){this.x=0;this.y=0;this.z=0;} set(x,y,z){this.x=x;this.y=y;this.z=z;return this;} }
  class O3 { constructor(geo, mat){this.geometry=geo||{setFromPoints(){return this;},dispose(){},setAttribute(){}};this.material=mat||{};this.position=new V3();this.rotation=new E();this.children=[];this.up=new V3(0,1,0);this.castShadow=false;this.receiveShadow=false;this.quaternion={setFromUnitVectors(){return this;}};} add(...c){this.children.push(...c);return this;} remove(c){this.children=this.children.filter(x=>x!==c);} clone(){const o=new this.constructor(this.geometry,this.material);o.position.copy(this.position);return o;} lookAt(){} computeLineDistances(){return this;} updateProjectionMatrix(){} }
  class Geo { constructor(){} setFromPoints(){return this;} setAttribute(){} dispose(){} }
  class Mat { constructor(o){Object.assign(this,o||{});} }
  class Color { constructor(c){this.c=c;} set(c){this.c=c;return this;} }
  const T = { Vector3:V3, Color, Group:O3, Mesh:O3, Line:O3, Scene:O3, PerspectiveCamera:class extends O3{constructor(){super();this.aspect=1;}},
    HemisphereLight:O3, DirectionalLight:class extends O3{constructor(){super();this.shadow={mapSize:new V3(),camera:new O3(),bias:0};}},
    PlaneGeometry:Geo, TorusGeometry:Geo, BoxGeometry:Geo, CylinderGeometry:Geo, ConeGeometry:Geo, SphereGeometry:Geo, BufferGeometry:Geo, BufferAttribute:class{},
    MeshStandardMaterial:Mat, MeshBasicMaterial:Mat, LineBasicMaterial:Mat, LineDashedMaterial:Mat, Fog:class{},
    CanvasTexture:class{}, RepeatWrapping:1, PCFSoftShadowMap:2, sRGBEncoding:3,
    WebGLRenderer:class{constructor(){this.domElement=document.createElement('canvas');this.shadowMap={};} setPixelRatio(){} setSize(){} render(){ window.__renders=(window.__renders||0)+1; }} };
  window.THREE = T;
})();
