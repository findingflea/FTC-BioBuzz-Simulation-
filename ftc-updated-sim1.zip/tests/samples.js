exports.auton = `
package org.firstinspires.ftc.teamcode;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.util.ElapsedTime;

@Autonomous(name="Encoder Auto", group="Robot")
public class EncoderAuto extends LinearOpMode {
    private DcMotor leftFront, rightFront, leftBack, rightBack;
    private ElapsedTime runtime = new ElapsedTime();
    static final double COUNTS_PER_MOTOR_REV = 537.7;
    static final double WHEEL_DIAMETER_INCHES = 3.78;
    static final double COUNTS_PER_INCH = COUNTS_PER_MOTOR_REV / (WHEEL_DIAMETER_INCHES * Math.PI);
    enum State { DRIVE, TURN, DONE }

    @Override
    public void runOpMode() {
        leftFront = hardwareMap.get(DcMotor.class, "leftFront");
        rightFront = hardwareMap.get(DcMotor.class, "rightFront");
        leftBack = hardwareMap.get(DcMotor.class, "leftBack");
        rightBack = hardwareMap.get(DcMotor.class, "rightBack");
        leftFront.setDirection(DcMotor.Direction.REVERSE);
        leftBack.setDirection(DcMotor.Direction.REVERSE);
        for (DcMotor m : new DcMotor[]{leftFront, rightFront, leftBack, rightBack}) {
            m.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            m.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        }
        telemetry.addData("Status", "Ready");
        telemetry.update();
        waitForStart();
        encoderDrive(0.6, 24, 24, 5.0);
        encoderDrive(0.5, 12, -12, 4.0);
        State s = State.DONE;
        switch (s) { case DONE: telemetry.addLine("done"); break; default: break; }
        int half = 7 / 2;
        telemetry.addData("half", half);
        telemetry.addData("Path", "Complete %.2f", runtime.seconds());
        telemetry.update();
        sleep(1000);
    }

    public void encoderDrive(double speed, double leftInches, double rightInches, double timeoutS) {
        if (opModeIsActive()) {
            int newLeft = leftFront.getCurrentPosition() + (int)(leftInches * COUNTS_PER_INCH);
            int newRight = rightFront.getCurrentPosition() + (int)(rightInches * COUNTS_PER_INCH);
            leftFront.setTargetPosition(newLeft); leftBack.setTargetPosition(newLeft);
            rightFront.setTargetPosition(newRight); rightBack.setTargetPosition(newRight);
            leftFront.setMode(DcMotor.RunMode.RUN_TO_POSITION); leftBack.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            rightFront.setMode(DcMotor.RunMode.RUN_TO_POSITION); rightBack.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            runtime.reset();
            leftFront.setPower(Math.abs(speed)); rightFront.setPower(Math.abs(speed));
            leftBack.setPower(Math.abs(speed)); rightBack.setPower(Math.abs(speed));
            while (opModeIsActive() && (runtime.seconds() < timeoutS) && (leftFront.isBusy() && rightFront.isBusy())) {
                telemetry.addData("Running to", " %7d :%7d", newLeft, newRight);
                telemetry.addData("Currently at", " at %7d :%7d", leftFront.getCurrentPosition(), rightFront.getCurrentPosition());
                telemetry.update();
            }
            leftFront.setPower(0); rightFront.setPower(0); leftBack.setPower(0); rightBack.setPower(0);
            leftFront.setMode(DcMotor.RunMode.RUN_USING_ENCODER); rightFront.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
            leftBack.setMode(DcMotor.RunMode.RUN_USING_ENCODER); rightBack.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
            sleep(250);
        }
    }
}`;
exports.teleop = `
package org.firstinspires.ftc.teamcode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.*;
@TeleOp(name="Mecanum TeleOp")
public class MecanumTeleOp extends LinearOpMode {
    @Override
    public void runOpMode() throws InterruptedException {
        DcMotor frontLeftMotor = hardwareMap.dcMotor.get("frontLeftMotor");
        DcMotor backLeftMotor = hardwareMap.dcMotor.get("backLeftMotor");
        DcMotor frontRightMotor = hardwareMap.dcMotor.get("frontRightMotor");
        DcMotor backRightMotor = hardwareMap.dcMotor.get("backRightMotor");
        Servo claw = hardwareMap.get(Servo.class, "claw");
        DcMotorEx arm = hardwareMap.get(DcMotorEx.class, "arm");
        IMU imu = hardwareMap.get(IMU.class, "imu");
        imu.initialize(new IMU.Parameters(new RevHubOrientationOnRobot(
                RevHubOrientationOnRobot.LogoFacingDirection.UP,
                RevHubOrientationOnRobot.UsbFacingDirection.FORWARD)));
        frontLeftMotor.setDirection(DcMotorSimple.Direction.REVERSE);
        backLeftMotor.setDirection(DcMotorSimple.Direction.REVERSE);
        boolean clawOpen = false;
        waitForStart();
        if (isStopRequested()) return;
        while (opModeIsActive()) {
            double y = -gamepad1.left_stick_y;
            double x = gamepad1.left_stick_x * 1.1;
            double rx = gamepad1.right_stick_x;
            if (gamepad1.options) imu.resetYaw();
            double botHeading = imu.getRobotYawPitchRollAngles().getYaw(AngleUnit.RADIANS);
            double rotX = x * Math.cos(-botHeading) - y * Math.sin(-botHeading);
            double rotY = x * Math.sin(-botHeading) + y * Math.cos(-botHeading);
            double denominator = Math.max(Math.abs(rotY) + Math.abs(rotX) + Math.abs(rx), 1);
            frontLeftMotor.setPower((rotY + rotX + rx) / denominator);
            backLeftMotor.setPower((rotY - rotX + rx) / denominator);
            frontRightMotor.setPower((rotY - rotX - rx) / denominator);
            backRightMotor.setPower((rotY + rotX - rx) / denominator);
            if (gamepad1.aWasPressed()) clawOpen = !clawOpen;
            claw.setPosition(clawOpen ? 0.8 : 0.2);
            arm.setPower(gamepad1.right_trigger - gamepad1.left_trigger);
            telemetry.addData("Heading", Math.toDegrees(botHeading));
            telemetry.addData("Claw", clawOpen ? "open" : "closed");
            telemetry.update();
        }
    }
}`;
exports.iterative = `
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.util.Range;
@TeleOp(name="Tank Iterative", group="Iterative")
public class TankIter extends OpMode {
    private DcMotor left = null, right = null;
    private int loops;
    @Override public void init() {
        left = hardwareMap.get(DcMotor.class, "left_drive");
        right = hardwareMap.get(DcMotor.class, "right_drive");
        left.setDirection(DcMotor.Direction.REVERSE);
        telemetry.addData("Status", "Initialized");
    }
    @Override public void loop() {
        double drive = -gamepad1.left_stick_y, turn = gamepad1.right_stick_x;
        double lp = Range.clip(drive + turn, -1.0, 1.0);
        double rp = Range.clip(drive - turn, -1.0, 1.0);
        left.setPower(lp); right.setPower(rp);
        loops++;
        telemetry.addData("Motors", "left (%.2f), right (%.2f)", lp, rp);
        telemetry.addData("Loops", loops);
        telemetry.addData("Run Time", getRuntime());
    }
}`;
