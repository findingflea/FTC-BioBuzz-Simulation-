const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch();
  const out = '/tmp/claude-0/-home-claude/cd368983-4dea-5714-a6a0-d370919067ba/scratchpad';
  for (const scheme of ['dark', 'light']) {
    const p = await b.newPage({ viewport: { width: 1440, height: 900 }, colorScheme: scheme });
    const errs = [];
    p.on('pageerror', e => errs.push('pageerror: ' + e.message));
    p.on('console', m => { if (m.type() === 'error') errs.push('console: ' + m.text()); });
    await p.goto('file:///home/claude/ftcsim/dist/test.html');
    await p.waitForTimeout(2500);
    const info = await p.evaluate(() => ({
      state: document.querySelector('#state').textContent, clock: document.querySelector('#clock').textContent,
      tele: document.querySelector('#tele').innerText, devs: document.querySelectorAll('#devs .dev').length,
      hud: [...document.querySelectorAll('.hud b')].map(x => x.textContent).join(' '), compile: document.querySelector('#compileMsg').textContent,
      time: document.querySelector('#tlTime').textContent, renders: window.__renders, log: document.querySelector('#log').innerText.slice(0, 200),
      hwRows: document.querySelectorAll('.hw-row').length,
    }));
    console.log(scheme, JSON.stringify(info), errs);
    await p.screenshot({ path: `${out}/desk-${scheme}.png` });
    if (scheme === 'light') { await p.close(); continue; }
    // TeleOp flow
    await p.selectOption('#exampleSel', 'field-centric');
    await p.waitForTimeout(400);
    await p.click('#btnInit');
    await p.waitForTimeout(500);
    const gpVisible = await p.isVisible('#gamepad');
    await p.click('#btnStart');
    await p.mouse.click(700, 400); // focus viewport
    await p.keyboard.down('KeyW'); await p.waitForTimeout(1200); await p.keyboard.up('KeyW');
    await p.keyboard.down('ArrowRight'); await p.waitForTimeout(500); await p.keyboard.up('ArrowRight');
    const btn = await p.$('[data-btn="a"]'); const bb = await btn.boundingBox();
    await p.mouse.move(bb.x + bb.width / 2, bb.y + bb.height / 2); await p.mouse.down(); await p.waitForTimeout(150); await p.mouse.up();
    await p.waitForTimeout(300);
    const mid = await p.evaluate(() => ({ state: document.querySelector('#state').textContent, hud: [...document.querySelectorAll('.hud b')].map(x => x.textContent).join(' '), tele: document.querySelector('#tele').innerText, clock: document.querySelector('#clock').textContent }));
    await p.screenshot({ path: `${out}/teleop-live.png` });
    await p.click('#btnStop');
    await p.waitForTimeout(2200);
    const end = await p.evaluate(() => ({ state: document.querySelector('#state').textContent, gp: !document.querySelector('#gamepad').hidden, scrubMax: document.querySelector('#scrub').max }));
    console.log('teleop', gpVisible, JSON.stringify(mid), JSON.stringify(end), errs);
    // error flow
    await p.fill('#code', 'import com.qualcomm.robotcore.eventloop.opmode.*;\n@Autonomous public class X extends LinearOpMode {\n public void runOpMode() {\n  waitForStart();\n  DcMotor m = null;\n  m.setPower(1);\n }\n}');
    await p.waitForTimeout(900);
    await p.click('#btnRun');
    await p.waitForTimeout(800);
    const er = await p.evaluate(() => ({ state: document.querySelector('#state').textContent, box: document.querySelector('#errBox').innerText, line: !document.querySelector('#errLine').hidden }));
    console.log('error', JSON.stringify(er));
    await p.screenshot({ path: `${out}/error.png` });
    await p.close();
  }
  const m = await b.newPage({ viewport: { width: 390, height: 844 }, colorScheme: 'dark', isMobile: true, hasTouch: true });
  await m.goto('file:///home/claude/ftcsim/dist/test.html');
  await m.waitForTimeout(2000);
  const ov = await m.evaluate(() => ({ sw: document.documentElement.scrollWidth, w: innerWidth }));
  console.log('mobile overflow', JSON.stringify(ov));
  await m.screenshot({ path: `${out}/mobile.png`, fullPage: false });
  await m.selectOption('#exampleSel', 'tank-iterative'); await m.waitForTimeout(300);
  await m.click('#btnInit'); await m.waitForTimeout(400);
  await m.screenshot({ path: `${out}/mobile-pad.png` });
  await b.close();
})();
