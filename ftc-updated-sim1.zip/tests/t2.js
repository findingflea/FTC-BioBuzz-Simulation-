const run = require('./run.js'); const S = require('./samples.js');
// teleop: push left stick up for 1s, then strafe right 1s, then rotate, press A
let phase = s => s.t < 1.5 ? {left_stick_y: -1} : s.t < 2.5 ? {left_stick_x: 1} : s.t < 3.0 ? {right_stick_x: 0.5, a: s.t > 2.7} : {right_trigger: 1};
let simRef = {t:0};
const { sim } = run(S.teleop, { live: 4, input: function(){ return { gamepad1: phase(this), gamepad2: {} }; }, cfg: {} });
simRef = sim;
console.log('teleop errors', sim.errors.map(e => e.type + ' ' + e.message + ' L' + e.line));
const r = sim.robot; console.log('pose', r.x.toFixed(1), r.y.toFixed(1), (r.h*180/Math.PI).toFixed(1));
console.log('tele', JSON.stringify(sim.tele[sim.tele.length-1].lines));
console.log('claw', sim.devices.get('claw').act.toFixed(2), 'arm', sim.devices.get('arm').getCurrentPosition());
