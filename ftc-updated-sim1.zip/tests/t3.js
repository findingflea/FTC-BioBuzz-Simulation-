const run = require('./run.js'); const S = require('./samples.js');
let s0; const { sim } = run(S.iterative, { live: 2.5, input: () => ({ gamepad1: { left_stick_y: -0.5, right_stick_x: 0.2 } }), each: s => s0 = s });
console.log('iter errors', sim.errors, 'drive', sim.drive, 'pose', sim.robot.x.toFixed(1), sim.robot.y.toFixed(1), (sim.robot.h*180/Math.PI).toFixed(1));
console.log(JSON.stringify(sim.tele[sim.tele.length-1].lines));
const bad = (name, src) => { try { const { sim } = run(src); console.log(name, '->', sim.errors.map(e => `${e.type}: ${e.message} (line ${e.line})`).join(' | ') || 'no error', '|', sim.stopReason); } catch (e) { console.log(name, 'COMPILE', e.name, e.message, 'line', e.line); } };
const wrap = body => `import com.qualcomm.robotcore.eventloop.opmode.*; import com.qualcomm.robotcore.hardware.*;
@Autonomous public class T extends LinearOpMode { DcMotor m; public void runOpMode() {
${body}
} }`;
bad('npe', wrap('waitForStart();\nm.setPower(1);'));
bad('rtp no target', wrap('m = hardwareMap.get(DcMotor.class,"m");\nwaitForStart();\nm.setMode(DcMotor.RunMode.RUN_TO_POSITION);'));
bad('undeclared', wrap('waitForStart();\nfoo = 3;'));
bad('syntax', wrap('waitForStart()\nsleep(10);'));
bad('format %d double', wrap('waitForStart();\ntelemetry.addData("x","%d", 1.5); telemetry.update();'));
bad('infinite no sleep', wrap('waitForStart();\nint i=0; while (true) { i++; }'));
bad('div zero', wrap('waitForStart();\nint a=0; int b = 5/a;'));
bad('try catch', wrap('waitForStart();\ntry { throw new IllegalStateException("boom"); } catch (IllegalStateException e) { telemetry.addData("caught", e.getMessage()); telemetry.update(); }'));
bad('roadrunner', `import com.acmerobotics.roadrunner.Pose2d; import com.qualcomm.robotcore.eventloop.opmode.*;
@Autonomous public class R extends LinearOpMode { public void runOpMode() { Pose2d p = new Pose2d(0,0,0); waitForStart(); } }`);
bad('string concat', wrap('double d = 3; int i = 7/2; String s = "d=" + d + " i=" + i + " c=" + \'x\'; telemetry.addLine(s); telemetry.update(); waitForStart(); telemetry.addData("ok", s); telemetry.update();'));
const { sim: s2 } = run(wrap('double d = 3; int i = 7/2; float f = 0.1f; String s = "d=" + d + " i=" + i + " c=" + \'x\' + " f=" + f; telemetry.addLine(s); telemetry.addData("pct", "%5.1f%%", 12.345); telemetry.update(); waitForStart();'));
console.log(JSON.stringify(s2.tele.map(t=>t.lines)));
