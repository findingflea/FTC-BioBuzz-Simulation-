const run = require('./run.js');
const src = `
package org.firstinspires.ftc.teamcode;
import com.qualcomm.robotcore.eventloop.opmode.*;
import com.qualcomm.robotcore.hardware.*;
import com.qualcomm.robotcore.util.*;
import java.util.*;

@Autonomous(name="Hardware Class Auto")
public class HwAuto extends LinearOpMode {
    RobotHardware robot = new RobotHardware(this);
    enum Spot { NEAR(12.0), FAR(30.0); final double inches; Spot(double in) { inches = in; } double half() { return inches / 2; } }
    interface Step { void go(); }
    private static final int[] PATTERN = {1, 2, 3};

    @Override public void runOpMode() {
        robot.init();
        ElapsedTime t = new ElapsedTime(ElapsedTime.Resolution.MILLISECONDS);
        List<Double> speeds = new ArrayList<>();
        speeds.add(0.3); speeds.add(0.5);
        Map<String, Integer> counts = new HashMap<>();
        counts.put("a", 1);
        counts.put("a", counts.getOrDefault("a", 0) + 1);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < PATTERN.length; i += 1) sb.append(PATTERN[i]).append(',');
        telemetry.addData("pattern", sb.toString());
        telemetry.addData("count", counts.get("a"));
        telemetry.addData("spot", Spot.FAR + " " + Spot.FAR.half() + " " + Spot.valueOf("NEAR").ordinal());
        telemetry.update();
        waitForStart();
        Spot target = Spot.NEAR;
        switch (target) {
            case NEAR -> robot.driveInches(target.inches, speeds.get(1));
            case FAR -> robot.driveInches(target.inches, speeds.get(0));
        }
        outer:
        for (int a = 0; a < 3; a++) {
            for (int b = 0; b < 3; b++) { if (a * b == 2) break outer; }
        }
        int n = 0;
        do { n++; idle(); } while (n < 5 && opModeIsActive());
        Step s = () -> robot.setDrive(0, 0);
        s.go();
        String msg = String.format(Locale.US, "%s done in %.1f ms, n=%d", "drive", t.milliseconds(), n);
        long now = System.currentTimeMillis();
        telemetry.addLine(msg);
        telemetry.addData("ok", now > 0);
        telemetry.update();
        robot.helper(3);
        robot.helper(3, 4);
        sleep(200);
        robot.crash();
    }
}

class RobotHardware {
    private LinearOpMode myOpMode = null;
    private DcMotor leftDrive, rightDrive;
    public static final double TICKS_PER_INCH = 537.7 / (3.78 * Math.PI);
    public RobotHardware(LinearOpMode opmode) { myOpMode = opmode; }
    public void init() {
        leftDrive = myOpMode.hardwareMap.get(DcMotor.class, "left_drive");
        rightDrive = myOpMode.hardwareMap.get(DcMotor.class, "right_drive");
        leftDrive.setDirection(DcMotor.Direction.REVERSE);
        myOpMode.telemetry.addData(">", "Hardware Initialized");
        myOpMode.telemetry.update();
    }
    public void setDrive(double l, double r) { leftDrive.setPower(l); rightDrive.setPower(r); }
    public void driveInches(double in, double speed) {
        int target = leftDrive.getCurrentPosition() + (int) Math.round(in * TICKS_PER_INCH);
        setDrive(speed, speed);
        while (myOpMode.opModeIsActive() && leftDrive.getCurrentPosition() < target) {
            myOpMode.telemetry.addData("pos", leftDrive.getCurrentPosition());
            myOpMode.telemetry.update();
        }
        setDrive(0, 0);
        myOpMode.sleep(100);
    }
    public int helper(int a) { return a * 2; }
    public int helper(int a, int b) { return a + b; }
    public void crash() { int[] arr = new int[2]; Object o = null; o.toString(); }
}`;
const { sim } = run(src);
console.log('errors', sim.errors.map(e => `${e.type}: ${e.message} (line ${e.line})`));
console.log('tele', JSON.stringify(sim.tele.map(t => t.lines).filter((x, i, a) => i < 2 || i > a.length - 3)));
console.log('pose', sim.robot.x.toFixed(1), sim.robot.y.toFixed(1), 'drive', sim.drive, Object.entries(sim.cfg.devices).map(([k, v]) => k + ':' + v.role).join(' '));
