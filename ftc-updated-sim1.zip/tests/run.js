const F = require('../src/parser.js'); require('../src/emitter.js'); require('../src/runtime.js'); require('../src/sdk.js'); require('../src/sim.js'); require('../src/game.js');
function run(src, opts = {}) {
  const comp = F.compileJava(src);
  const cfg = Object.assign(F.defaultConfig(), opts.cfg || {});
  for (const d of F.prescanDevices(src)) F.ensureDevice(cfg, d.name, d.type);
  const sim = new F.Sim(cfg);
  if (opts.input) sim.input = opts.input;
  const op = comp.opModes[0];
  sim.load(comp, op);
  if (opts.live) {
    while (sim.t < opts.live) { if (!sim.started && sim.t > 0.5) sim.start(); sim.step(); if (opts.each) opts.each(sim); }
    sim.requestStop(); for (let i = 0; i < 400 && !sim.finished; i++) sim.step();
  } else sim.runFast(opts.fast || {});
  return { sim, comp };
}
module.exports = run;
if (require.main === module) {
  const S = require('./samples.js');
  const { sim } = run(S.auton);
  const r = sim.robot;
  console.log('errors', sim.errors);
  console.log('drive', sim.drive, 'roles', Object.entries(sim.cfg.devices).map(([k, v]) => k + ':' + v.role).join(' '));
  console.log('final pose', r.x.toFixed(2), r.y.toFixed(2), (r.h * 180 / Math.PI).toFixed(1), 't', sim.t.toFixed(2), 'end', sim.endT && sim.endT.toFixed(2), sim.stopReason);
  console.log('frames', sim.frames.length, 'tele', sim.tele.length, 'logs', sim.logs.filter(l => l.level !== 'event').length);
  console.log('last tele', JSON.stringify(sim.tele[sim.tele.length - 1].lines));
  // pose after first drive (~)
  const at = t => (sim.frames.find(f => f.f[0] >= t) || sim.frames[sim.frames.length - 1]).f;
  for (const t of [1, 2, 3, 4, 5, 6]) { const f = at(t); console.log('t=' + t, f[1].toFixed(1), f[2].toFixed(1), (f[3] * 180 / Math.PI).toFixed(1)); }
}
