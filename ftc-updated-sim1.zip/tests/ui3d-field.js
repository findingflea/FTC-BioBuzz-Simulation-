const { chromium } = require('playwright');
const out = '/tmp/claude-0/-home-claude/cd368983-4dea-5714-a6a0-d370919067ba/scratchpad';
(async () => {
  const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const p = await b.newPage({ viewport: { width: 1440, height: 900 }, colorScheme: 'dark' });
  const errs = [];
  p.on('pageerror', e => errs.push('pageerror: ' + e.message));
  p.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  await p.goto('file:///home/claude/ftcsim/dist/test3d.html');
  await p.waitForTimeout(6000);
  await p.screenshot({ path: `${out}/field-orbit.png` });
  // closer look at the hive
  await p.evaluate(() => { const s = FTC.App.scene; s.cam.theta = -Math.PI / 2 - 0.6; s.cam.phi = 1.1; s.cam.radius = 120; s.cam.target.set(0, 22, 0); });
  await p.waitForTimeout(600);
  await p.screenshot({ path: `${out}/field-hive.png`, clip: { x: 460, y: 60, width: 680, height: 600 } });
  await p.click('[data-cam="top"]'); await p.waitForTimeout(700);
  await p.screenshot({ path: `${out}/field-top.png`, clip: { x: 460, y: 60, width: 680, height: 680 } });
  console.log(JSON.stringify(errs));
  await b.close();
})();
