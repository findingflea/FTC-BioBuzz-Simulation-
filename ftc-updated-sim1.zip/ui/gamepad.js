/* Floating, draggable on-screen gamepad. Merges pointer, keyboard and physical gamepad input. */
(function (G) {
'use strict';
const FTC = (G.FTC = G.FTC || {});
const BTN = ['a', 'b', 'x', 'y', 'dpad_up', 'dpad_down', 'dpad_left', 'dpad_right', 'left_bumper', 'right_bumper', 'left_stick_button', 'right_stick_button', 'start', 'back', 'guide'];
const KEYMAP = {
  KeyK: 'a', KeyL: 'b', KeyJ: 'x', KeyI: 'y',
  KeyT: 'dpad_up', KeyG: 'dpad_down', KeyF: 'dpad_left', KeyH: 'dpad_right',
  KeyZ: 'left_bumper', KeyC: 'right_bumper', KeyV: 'left_stick_button', KeyN: 'right_stick_button',
  BracketRight: 'start', BracketLeft: 'back', Backslash: 'guide',
};
const KEYS_LEFT = { KeyW: [0, -1], KeyS: [0, 1], KeyA: [-1, 0], KeyD: [1, 0] };
const KEYS_RIGHT = { ArrowUp: [0, -1], ArrowDown: [0, 1], ArrowLeft: [-1, 0], ArrowRight: [1, 0] };
const KEY_HELP = [
  ['W A S D', 'Left stick'], ['← ↑ → ↓', 'Right stick'], ['Q / E', 'Left / right trigger'], ['Z / C', 'Left / right bumper'],
  ['I J K L', 'Y X A B'], ['T F G H', 'D-pad ↑ ← ↓ →'], ['[ / ]', 'Back / Start'], ['\\', 'Guide'], ['V / N', 'Left / right stick button'],
];
const blank = () => { const s = { left_stick_x: 0, left_stick_y: 0, right_stick_x: 0, right_stick_y: 0, left_trigger: 0, right_trigger: 0 }; for (const b of BTN) s[b] = false; return s; };

function controllerSVG() {
  return `<svg class="gp-shell" viewBox="0 0 360 230" aria-hidden="true"><path d="M92 42 C 60 42 40 52 28 80 C 12 118 4 168 10 196 C 16 222 44 226 62 208 C 80 190 96 168 120 164 L 240 164 C 264 168 280 190 298 208 C 316 226 344 222 350 196 C 356 168 348 118 332 80 C 320 52 300 42 268 42 Z"/></svg>`;
}

class GamepadPanel {
  constructor(root) {
    this.root = root;
    this.pads = { 1: blank(), 2: blank() };
    this.active = 1;
    this.keyTarget = 1;
    this.keys = new Set();
    this.physical = null;
    // which browser gamepad index drives gamepad1 / gamepad2 (set by the Connect controller dialog)
    this.physMap = { 1: null, 2: null };
    this.listeners = new Set();
    this.visible = false;
    this.build();
    this.bindKeys();
    try {
      G.addEventListener('gamepadconnected', e => { this.autoAssign(e.gamepad); this.scanPhysical(); this.emit(); });
      G.addEventListener('gamepaddisconnected', e => { for (const k of [1, 2]) if (this.physMap[k] === e.gamepad.index) this.physMap[k] = null; this.scanPhysical(); this.emit(); });
    } catch (e) { /* not allowed */ }
  }
  build() {
    const r = this.root;
    r.innerHTML = `
      <div class="gp-head" data-drag>
        <span class="gp-grip" aria-hidden="true"></span>
        <div class="seg" role="tablist" aria-label="Which gamepad">
          <button type="button" role="tab" class="on" data-pad="1" id="gpTab1">Gamepad 1</button>
          <button type="button" role="tab" data-pad="2" id="gpTab2">Gamepad 2</button>
        </div>
        <span class="gp-rumble" title="Rumble"></span>
        <button type="button" class="icon-btn" data-act="keys" title="Keyboard controls" aria-label="Keyboard controls">⌨</button>
        <button type="button" class="icon-btn" data-act="min" title="Minimize" aria-label="Minimize">–</button>
      </div>
      <div class="gp-body">
        <div class="gp-pad">
          ${controllerSVG()}
          <div class="trig" data-trig="left_trigger" style="left:50px;top:0"><i></i><span>LT</span></div>
          <div class="trig" data-trig="right_trigger" style="right:50px;top:0"><i></i><span>RT</span></div>
          <button type="button" class="bump" data-btn="left_bumper" style="left:36px;top:38px">LB</button>
          <button type="button" class="bump" data-btn="right_bumper" style="right:36px;top:38px">RB</button>
          <div class="stick" data-stick="left" style="left:34px;top:72px"><i></i></div>
          <button type="button" class="mini" data-btn="left_stick_button" style="left:52px;top:150px" title="Left stick button">L3</button>
          <div class="dpad" style="left:100px;top:140px">
            <button type="button" data-btn="dpad_up" class="du" aria-label="D-pad up"></button>
            <button type="button" data-btn="dpad_left" class="dl" aria-label="D-pad left"></button>
            <button type="button" data-btn="dpad_right" class="dr" aria-label="D-pad right"></button>
            <button type="button" data-btn="dpad_down" class="dd" aria-label="D-pad down"></button>
          </div>
          <div class="stick" data-stick="right" style="left:194px;top:142px"><i></i></div>
          <button type="button" class="mini" data-btn="right_stick_button" style="left:270px;top:192px" title="Right stick button">R3</button>
          <div class="face" style="right:28px;top:64px">
            <button type="button" data-btn="y" class="fy">Y</button>
            <button type="button" data-btn="x" class="fx">X</button>
            <button type="button" data-btn="b" class="fb">B</button>
            <button type="button" data-btn="a" class="fa">A</button>
          </div>
          <button type="button" class="mini" data-btn="back" style="left:118px;top:84px">back</button>
          <button type="button" class="mini round" data-btn="guide" style="left:166px;top:104px" aria-label="Guide">●</button>
          <button type="button" class="mini" data-btn="start" style="left:200px;top:84px">start</button>
        </div>
        <div class="gp-keys" hidden>
          ${KEY_HELP.map(([k, v]) => `<div><kbd>${k}</kbd><span>${v}</span></div>`).join('')}
          <p>Keys drive <b class="gp-keytarget">gamepad 1</b>. Click in the 3D view first if typing goes to the editor.</p>
        </div>
      </div>
      <div class="gp-foot"><span class="gp-src">Drag the sticks, press buttons, or use the keyboard.</span><span class="gp-readout"></span></div>`;
    // tabs
    r.querySelectorAll('[data-pad]').forEach(b => b.addEventListener('click', () => this.setActive(Number(b.dataset.pad))));
    r.querySelector('[data-act="keys"]').addEventListener('click', () => { const k = r.querySelector('.gp-keys'); k.hidden = !k.hidden; });
    r.querySelector('[data-act="min"]').addEventListener('click', () => r.classList.toggle('min'));
    // buttons
    r.querySelectorAll('[data-btn]').forEach(el => {
      const name = el.dataset.btn;
      const down = e => { e.preventDefault(); try { el.setPointerCapture(e.pointerId); } catch (x) { /* ignore */ } this.pads[this.active][name] = true; };
      const up = () => { this.pads[this.active][name] = false; };
      el.addEventListener('pointerdown', down);
      el.addEventListener('pointerup', up);
      el.addEventListener('pointercancel', up);
      el.addEventListener('lostpointercapture', up);
    });
    // sticks
    r.querySelectorAll('[data-stick]').forEach(el => {
      const side = el.dataset.stick;
      let id = null;
      const move = e => {
        const b = el.getBoundingClientRect();
        let x = (e.clientX - (b.left + b.width / 2)) / (b.width / 2), y = (e.clientY - (b.top + b.height / 2)) / (b.height / 2);
        const m = Math.hypot(x, y); if (m > 1) { x /= m; y /= m; }
        this.pads[this.active][side + '_stick_x'] = x;
        this.pads[this.active][side + '_stick_y'] = y;
      };
      el.addEventListener('pointerdown', e => { e.preventDefault(); id = e.pointerId; el.setPointerCapture(id); el.classList.add('grab'); move(e); });
      el.addEventListener('pointermove', e => { if (e.pointerId === id) move(e); });
      const end = e => { if (e.pointerId !== id) return; id = null; el.classList.remove('grab'); this.pads[this.active][side + '_stick_x'] = 0; this.pads[this.active][side + '_stick_y'] = 0; };
      el.addEventListener('pointerup', end); el.addEventListener('pointercancel', end);
    });
    // triggers: press and drag down to pull further
    r.querySelectorAll('[data-trig]').forEach(el => {
      const name = el.dataset.trig;
      let id = null;
      const move = e => { const b = el.getBoundingClientRect(); this.pads[this.active][name] = Math.min(1, Math.max(0.05, (e.clientY - b.top) / b.height)); };
      el.addEventListener('pointerdown', e => { e.preventDefault(); id = e.pointerId; el.setPointerCapture(id); this.pads[this.active][name] = 1; });
      el.addEventListener('pointermove', e => { if (e.pointerId === id && e.buttons) move(e); });
      const end = e => { if (e.pointerId !== id) return; id = null; this.pads[this.active][name] = 0; };
      el.addEventListener('pointerup', end); el.addEventListener('pointercancel', end);
    });
    this.makeDraggable(r.querySelector('[data-drag]'));
  }
  makeDraggable(handle) {
    const r = this.root;
    let start = null;
    handle.addEventListener('pointerdown', e => {
      if (e.target.closest('button')) return;
      const b = r.getBoundingClientRect();
      start = { x: e.clientX, y: e.clientY, l: b.left, t: b.top };
      handle.setPointerCapture(e.pointerId);
    });
    handle.addEventListener('pointermove', e => {
      if (!start) return;
      const w = r.offsetWidth, h = r.offsetHeight;
      const l = Math.min(G.innerWidth - w - 4, Math.max(4, start.l + e.clientX - start.x));
      const t = Math.min(G.innerHeight - 40, Math.max(4, start.t + e.clientY - start.y));
      Object.assign(r.style, { left: l + 'px', top: t + 'px', right: 'auto', bottom: 'auto' });
    });
    handle.addEventListener('pointerup', () => { start = null; });
  }
  setActive(n) {
    this.active = n;
    this.keyTarget = n;
    this.root.querySelectorAll('[data-pad]').forEach(b => b.classList.toggle('on', Number(b.dataset.pad) === n));
    const kt = this.root.querySelector('.gp-keytarget'); if (kt) kt.textContent = 'gamepad ' + n;
  }
  bindKeys() {
    const typing = e => { const t = e.target; return t && (t.tagName === 'TEXTAREA' || t.tagName === 'INPUT' || t.tagName === 'SELECT' || t.isContentEditable); };
    G.addEventListener('keydown', e => {
      if (!this.visible || typing(e) || e.metaKey || e.ctrlKey || e.altKey) return;
      const known = KEYMAP[e.code] || KEYS_LEFT[e.code] || KEYS_RIGHT[e.code] || e.code === 'KeyQ' || e.code === 'KeyE';
      if (!known) return;
      e.preventDefault();
      this.keys.add(e.code);
    });
    G.addEventListener('keyup', e => this.keys.delete(e.code));
    G.addEventListener('blur', () => this.keys.clear());
  }
  scanPhysical() {
    try {
      const list = navigator.getGamepads ? [...navigator.getGamepads()].filter(Boolean) : [];
      list.forEach(g => this.autoAssign(g));
      this.physical = list;
      const src = this.root.querySelector('.gp-src');
      if (src) src.textContent = list.length ? `Physical controller: ${list.map(g => g.id.split('(')[0].trim()).join(', ')}` : 'Drag the sticks, press buttons, or use the keyboard.';
    } catch (e) { this.physical = null; }
  }
  /* ---- physical controllers */
  apiStatus() {
    if (!navigator.getGamepads) return 'unsupported';
    try { navigator.getGamepads(); return 'ok'; } catch (e) { return 'blocked'; }
  }
  connected() {
    try { return navigator.getGamepads ? [...navigator.getGamepads()].filter(Boolean) : []; } catch (e) { return []; }
  }
  autoAssign(gp) {
    if (!gp) return;
    if (this.physMap[1] === gp.index || this.physMap[2] === gp.index) return;
    if (this.physMap[1] == null) this.physMap[1] = gp.index;
    else if (this.physMap[2] == null) this.physMap[2] = gp.index;
  }
  assign(user, index) {
    for (const k of [1, 2]) if (this.physMap[k] === index) this.physMap[k] = null;
    this.physMap[user] = index;
    this.emit();
  }
  onChange(fn) { this.listeners.add(fn); }
  emit() { for (const fn of this.listeners) try { fn(); } catch (e) { /* ignore */ } }
  readPhysical(user) {
    try {
      if (!navigator.getGamepads) return null;
      const idx = this.physMap[user];
      if (idx == null) return null;
      const g = navigator.getGamepads()[idx];
      if (!g) return null;
      const s = blank();
      const ax = i => g.axes[i] || 0;
      s.left_stick_x = ax(0); s.left_stick_y = ax(1); s.right_stick_x = ax(2); s.right_stick_y = ax(3);
      const b = i => g.buttons[i] && g.buttons[i].pressed;
      const order = ['a', 'b', 'x', 'y', 'left_bumper', 'right_bumper', null, null, 'back', 'start', 'left_stick_button', 'right_stick_button', 'dpad_up', 'dpad_down', 'dpad_left', 'dpad_right', 'guide'];
      order.forEach((n, i) => { if (n) s[n] = !!b(i); });
      s.left_trigger = g.buttons[6] ? g.buttons[6].value : 0;
      s.right_trigger = g.buttons[7] ? g.buttons[7].value : 0;
      return s;
    } catch (e) { return null; }
  }
  /* merged state for the simulator */
  state(n) {
    const s = Object.assign({}, this.pads[n]);
    if (this.keyTarget === n && this.keys.size) {
      let lx = 0, ly = 0, rx = 0, ry = 0;
      for (const k of this.keys) {
        if (KEYS_LEFT[k]) { lx += KEYS_LEFT[k][0]; ly += KEYS_LEFT[k][1]; }
        if (KEYS_RIGHT[k]) { rx += KEYS_RIGHT[k][0]; ry += KEYS_RIGHT[k][1]; }
        if (KEYMAP[k]) s[KEYMAP[k]] = true;
      }
      const norm = (x, y) => { const m = Math.hypot(x, y); return m > 1 ? [x / m, y / m] : [x, y]; };
      if (lx || ly) [s.left_stick_x, s.left_stick_y] = norm(lx, ly);
      if (rx || ry) [s.right_stick_x, s.right_stick_y] = norm(rx, ry);
      if (this.keys.has('KeyQ')) s.left_trigger = 1;
      if (this.keys.has('KeyE')) s.right_trigger = 1;
    }
    const p = this.readPhysical(n);
    if (p) {
      for (const b of BTN) s[b] = s[b] || p[b];
      for (const k of ['left_stick_x', 'left_stick_y', 'right_stick_x', 'right_stick_y']) if (Math.abs(p[k]) > Math.abs(s[k])) s[k] = p[k];
      s.left_trigger = Math.max(s.left_trigger, p.left_trigger); s.right_trigger = Math.max(s.right_trigger, p.right_trigger);
    }
    return s;
  }
  input() { return { gamepad1: this.state(1), gamepad2: this.state(2) }; }
  show(on) {
    this.visible = on;
    this.root.hidden = !on;
    if (on) this.scanPhysical();
    if (!on) { this.keys.clear(); this.pads = { 1: blank(), 2: blank() }; }
  }
  /* refresh visuals each frame */
  paint(simPad) {
    if (!this.visible || this.root.classList.contains('min')) return;
    const s = this.state(this.active);
    const r = this.root;
    r.querySelectorAll('[data-btn]').forEach(el => el.classList.toggle('on', !!s[el.dataset.btn]));
    r.querySelectorAll('[data-stick]').forEach(el => {
      const side = el.dataset.stick;
      const k = el.firstElementChild;
      k.style.transform = `translate(${s[side + '_stick_x'] * 22}px, ${s[side + '_stick_y'] * 22}px)`;
      el.classList.toggle('on', !!s[side + '_stick_button']);
    });
    r.querySelectorAll('[data-trig]').forEach(el => { el.firstElementChild.style.transform = `scaleY(${s[el.dataset.trig]})`; });
    const ro = r.querySelector('.gp-readout');
    if (ro) ro.textContent = `LX ${s.left_stick_x.toFixed(2)}  LY ${s.left_stick_y.toFixed(2)}  RX ${s.right_stick_x.toFixed(2)}`;
    const rum = r.querySelector('.gp-rumble');
    const rumbling = simPad && simPad.isRumbling && simPad.isRumbling();
    rum.classList.toggle('on', !!rumbling);
    rum.textContent = rumbling ? 'rumble' : '';
    r.classList.toggle('shake', !!rumbling);
  }
}
FTC.GamepadPanel = GamepadPanel;
})(typeof globalThis !== 'undefined' ? globalThis : window);
