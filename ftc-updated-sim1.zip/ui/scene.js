/* Three.js scene: field, robot, mechanisms, trail, camera. Sim frame: x right, y away, z up (inches).
   Three: x = sim.x, y = up, z = -sim.y. */
(function (G) {
'use strict';
const FTC = (G.FTC = G.FTC || {});
const T = G.THREE;
const HALF = 72, WALL_H = 12;

function cssVar(n, fb) {
  try { const v = getComputedStyle(document.documentElement).getPropertyValue(n).trim(); return v || fb; } catch (e) { return fb; }
}

function tileTexture() {
  const c = document.createElement('canvas');
  c.width = c.height = 1536;
  const g = c.getContext('2d');
  const s = c.width / 6;
  for (let i = 0; i < 6; i++) for (let j = 0; j < 6; j++) {
    const v = 132 + ((i + j) % 2 ? 4 : -2);
    g.fillStyle = `rgb(${v - 4},${v},${v + 6})`;
    g.fillRect(i * s, j * s, s, s);
    // foam texture speckle
    for (let k = 0; k < 900; k++) {
      const a = Math.random() * 0.06;
      g.fillStyle = Math.random() < 0.5 ? `rgba(255,255,255,${a})` : `rgba(0,0,0,${a})`;
      g.fillRect(i * s + Math.random() * s, j * s + Math.random() * s, 2, 2);
    }
    // interlocking tab seams
    g.strokeStyle = 'rgba(40,44,50,0.55)';
    g.lineWidth = 3;
    g.beginPath();
    const tabs = 5, tw = s / tabs;
    for (let k = 0; k < tabs; k++) {
      const x0 = i * s + k * tw, y0 = j * s;
      const d = (k % 2 ? 1 : -1) * 7;
      g.moveTo(x0, y0); g.lineTo(x0 + tw * 0.3, y0); g.lineTo(x0 + tw * 0.3, y0 + d); g.lineTo(x0 + tw * 0.7, y0 + d); g.lineTo(x0 + tw * 0.7, y0); g.lineTo(x0 + tw, y0);
    }
    for (let k = 0; k < tabs; k++) {
      const y0 = j * s + k * tw, x0 = i * s;
      const d = (k % 2 ? 1 : -1) * 7;
      g.moveTo(x0, y0); g.lineTo(x0, y0 + tw * 0.3); g.lineTo(x0 + d, y0 + tw * 0.3); g.lineTo(x0 + d, y0 + tw * 0.7); g.lineTo(x0, y0 + tw * 0.7); g.lineTo(x0, y0 + tw);
    }
    g.stroke();
    // tile name: rows A-F (bottom to top), columns 1-6 (left to right)
    g.fillStyle = 'rgba(30,34,40,0.32)';
    g.font = `600 ${Math.round(s * 0.09)}px "Barlow Semi Condensed", sans-serif`;
    g.fillText('ABCDEF'[i] + (6 - j), i * s + s * 0.07, j * s + s * 0.16);
  }
  const t = new T.CanvasTexture(c);
  t.anisotropy = 8;
  return t;
}
function wheelTexture(mecanum, flip) {
  const c = document.createElement('canvas');
  c.width = 256; c.height = 64;
  const g = c.getContext('2d');
  g.fillStyle = '#26282c'; g.fillRect(0, 0, 256, 64);
  if (mecanum) {
    g.strokeStyle = '#5b6068'; g.lineWidth = 9;
    for (let x = -64; x < 320; x += 26) { g.beginPath(); g.moveTo(x, flip ? 0 : 64); g.lineTo(x + 40, flip ? 64 : 0); g.stroke(); }
  } else {
    g.fillStyle = '#3a3d42';
    for (let x = 0; x < 256; x += 16) g.fillRect(x, 0, 8, 64);
  }
  const t = new T.CanvasTexture(c);
  t.wrapS = T.RepeatWrapping;
  return t;
}

class Scene {
  constructor(host) {
    this.host = host;
    this.renderer = new T.WebGLRenderer({ antialias: true, preserveDrawingBuffer: false });
    this.renderer.setPixelRatio(Math.min(G.devicePixelRatio || 1, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = T.PCFSoftShadowMap;
    host.appendChild(this.renderer.domElement);
    this.scene = new T.Scene();
    this.camera = new T.PerspectiveCamera(42, 1, 1, 3000);
    this.cam = { mode: 'orbit', theta: -Math.PI / 2 - 0.35, phi: 0.95, radius: 230, target: new T.Vector3(0, 0, 0), follow: null };
    this.buildLights();
    this.buildField();
    this.gameGroup = null;
    this.robot = null;
    this.mechs = [];
    this.beams = [];
    this.trailLine = null;
    this.obstacleGroup = new T.Group();
    this.scene.add(this.obstacleGroup);
    this.bindControls();
    this.applyTheme();
    this.resize();
    if (G.ResizeObserver) new ResizeObserver(() => this.resize()).observe(host);
  }
  applyTheme() {
    const bg = new T.Color(cssVar('--viewport', '#1b1e22'));
    this.scene.background = bg;
    this.scene.fog = new T.Fog(bg, 420, 1100);
    if (this.ground) this.ground.material.color = new T.Color(cssVar('--viewport-floor', '#24282d'));
    this.accent = new T.Color(cssVar('--accent', '#f2b230'));
    if (this.trailLine) this.trailLine.material.color = this.accent;
    if (this.frontBar) this.frontBar.material.color = this.accent;
  }
  buildLights() {
    this.scene.add(new T.HemisphereLight(0xf2f4ff, 0x30343a, 0.75));
    const d = new T.DirectionalLight(0xffffff, 0.85);
    d.position.set(-90, 170, 70);
    d.castShadow = true;
    d.shadow.mapSize.set(2048, 2048);
    const sc = d.shadow.camera;
    sc.left = -100; sc.right = 100; sc.top = 100; sc.bottom = -100; sc.near = 10; sc.far = 400;
    sc.updateProjectionMatrix();
    d.shadow.bias = -0.0008;
    this.scene.add(d);
  }
  buildField() {
    const ground = new T.Mesh(new T.PlaneGeometry(2400, 2400), new T.MeshStandardMaterial({ color: 0x24282d, roughness: 1 }));
    ground.rotation.x = -Math.PI / 2; ground.position.y = -0.6; ground.receiveShadow = true;
    this.ground = ground;
    this.scene.add(ground);
    const mat = new T.MeshStandardMaterial({ map: tileTexture(), roughness: 0.95 });
    const floor = new T.Mesh(new T.BoxGeometry(144, 0.6, 144), [null, null, mat, null, null, null].map(m => m || new T.MeshStandardMaterial({ color: 0x6f747b })));
    floor.position.y = -0.3; floor.receiveShadow = true;
    this.scene.add(floor);
    // perimeter: aluminium rail + clear panels, red alliance on -X, blue alliance on +X
    const rail = new T.MeshStandardMaterial({ color: 0xb9bec5, metalness: 0.6, roughness: 0.35 });
    const panel = new T.MeshStandardMaterial({ color: 0xd8e6f2, transparent: true, opacity: 0.16, roughness: 0.1, depthWrite: false });
    const mk = (w, h, d, m, x, y, z, shadow) => { const o = new T.Mesh(new T.BoxGeometry(w, h, d), m); o.position.set(x, y, z); o.castShadow = !!shadow; o.receiveShadow = true; this.scene.add(o); return o; };
    for (const s of [-1, 1]) {
      mk(146, WALL_H, 0.25, panel, 0, WALL_H / 2, s * 72.6);
      mk(0.25, WALL_H, 146, panel, s * 72.6, WALL_H / 2, 0);
      mk(147, 1, 1, rail, 0, WALL_H, s * 72.6, true);
      mk(1, 1, 147, rail, s * 72.6, WALL_H, 0, true);
      mk(147, 2, 1, rail, 0, 1, s * 72.6, true);
      mk(1, 2, 147, rail, s * 72.6, 1, 0, true);
    }
    const red = new T.MeshStandardMaterial({ color: 0xd83a3f, roughness: 0.6 });
    const blue = new T.MeshStandardMaterial({ color: 0x2f6fd6, roughness: 0.6 });
    mk(1.2, 2.2, 146, red, -73.4, 1.1, 0);
    mk(1.2, 2.2, 146, blue, 73.4, 1.1, 0);
    // axis hint at the origin corner
    const ax = new T.Group();
    const arrow = (color, rotY) => {
      const g = new T.Group();
      const m = new T.MeshBasicMaterial({ color });
      const shaft = new T.Mesh(new T.BoxGeometry(10, 0.15, 0.5), m); shaft.position.x = 5;
      const head = new T.Mesh(new T.ConeGeometry(1.1, 2.6, 12), m); head.rotation.z = -Math.PI / 2; head.position.x = 11;
      g.add(shaft, head); g.rotation.y = rotY; return g;
    };
    ax.add(arrow(0xd83a3f, 0), arrow(0x46a758, Math.PI / 2));
    ax.position.set(-66, 0.12, 66);
    ax.visible = false;
    this.axisHint = ax;
    this.scene.add(ax);
    // start-pose outline
    const og = new T.BufferGeometry().setFromPoints([new T.Vector3(), new T.Vector3(), new T.Vector3(), new T.Vector3(), new T.Vector3()]);
    this.startOutline = new T.Line(og, new T.LineDashedMaterial({ color: 0xffffff, dashSize: 1.5, gapSize: 1.2, transparent: true, opacity: 0.6 }));
    this.scene.add(this.startOutline);
  }
  /* ---------- BIOBUZZ field elements (positions from FTC.BIOBUZZ in sim.js) */
  setGame(field) {
    if (this.gameGroup) { this.scene.remove(this.gameGroup); this.gameGroup = null; }
    if (field !== 'biobuzz' || !FTC.BIOBUZZ) return;
    const B = FTC.BIOBUZZ;
    const g = new T.Group();
    this.gameGroup = g;
    this.hiveGroups = [];
    const P = (x, y, z) => new T.Vector3(x, z, -y);              // sim inches -> three
    const mesh = (geo, mat, shadow = true) => { const m = new T.Mesh(geo, mat); m.castShadow = shadow; m.receiveShadow = true; return m; };
    const metal = new T.MeshStandardMaterial({ color: 0x9aa1aa, metalness: 0.6, roughness: 0.35 });
    const allianceMat = a => new T.MeshStandardMaterial({ color: a === 'red' ? 0xd83a3f : 0x2f6fd6, roughness: 0.55, side: T.DoubleSide });
    const strut = (a, b, r, mat) => {
      const dir = new T.Vector3().subVectors(b, a), len = dir.length();
      const m = mesh(new T.CylinderGeometry(r, r, len, 12), mat);
      m.position.copy(a).addScaledVector(dir, 0.5);
      m.quaternion.setFromUnitVectors(new T.Vector3(0, 1, 0), dir.normalize());
      g.add(m);
      return m;
    };
    // Center frame: two triangles (A-frames) joined by a crossbar at the pivot
    const fx = B.frame.w / 2 - 0.75, fy = B.frame.d / 2, pz = B.frame.pivotZ;
    for (const sx of [-1, 1]) {
      const apex = P(sx * fx, 0, pz);
      strut(P(sx * fx, -fy, 0.6), apex, 0.75, metal);
      strut(P(sx * fx, fy, 0.6), apex, 0.75, metal);
      strut(P(sx * fx, -fy, 0.6), P(sx * fx, fy, 0.6), 0.75, metal);
    }
    strut(P(-fx, 0, pz), P(fx, 0, pz), 0.9, metal);
    // HIVES: a beam along Y with a CELL at each end, tipped so one CELL faces up
    const C = B.cell, half = C.gap / 2;
    for (const h of B.hives) {
      const hg = new T.Group();
      hg.position.copy(P(h.x, 0, pz));
      const mat = allianceMat(h.alliance);
      const dark = new T.MeshStandardMaterial({ color: 0x2a2e34, roughness: 0.6 });
      // spine between the two CELLs, hanging from the pivot
      const spine = mesh(new T.BoxGeometry(C.w, 3, C.gap), dark);
      spine.position.set(0, -C.h + 1.5, 0);
      hg.add(spine);
      for (const end of [-1, 1]) {
        // open-topped box: bottom + 4 walls; local +Y is the CELL opening
        const cz = end * (half + C.d / 2);
        const wall = (w, hh, d, x, y, z) => { const m = mesh(new T.BoxGeometry(w, hh, d), mat); m.position.set(x, y, z); hg.add(m); };
        wall(C.w, 0.6, C.d, 0, -C.h, cz);                                   // bottom
        wall(0.5, C.h, C.d, -C.w / 2, -C.h / 2, cz);                        // sides
        wall(0.5, C.h, C.d, C.w / 2, -C.h / 2, cz);
        wall(C.w, C.h, 0.5, 0, -C.h / 2, cz + end * C.d / 2);               // outer end
        wall(C.w, C.h, 0.5, 0, -C.h / 2, cz - end * C.d / 2);               // inner end
        const tag = mesh(new T.PlaneGeometry(6, 6), new T.MeshBasicMaterial({ color: 0xf2f2f2, side: T.DoubleSide }), false);
        tag.rotation.x = -Math.PI / 2; tag.position.set(0, -C.h - 0.35, cz);   // AprilTag cluster under the CELL
        hg.add(tag);
      }
      // upEnd -1 raises the audience (-Y sim = +Z three) end, +1 raises the far end
      hg.rotation.x = (h.upEnd === -1 ? -1 : 1) * B.hiveTiltDeg * Math.PI / 180;
      g.add(hg);
      this.hiveGroups.push(hg);
    }
    // FLOWERS: tubes on the wall holding 4 POLLEN each
    const F = B.flower;
    const stem = new T.MeshStandardMaterial({ color: 0x3f8f4f, roughness: 0.6, side: T.DoubleSide });
    const petal = new T.MeshStandardMaterial({ color: 0xf2b230, roughness: 0.5 });
    const pollenMat = new T.MeshStandardMaterial({ color: 0xf2d43a, roughness: 0.7 });
    for (const f of B.flowers) {
      const fg = new T.Group();
      fg.position.copy(P(f.x, f.y, 0));
      const tube = mesh(new T.CylinderGeometry(F.outerD / 2, F.outerD / 2, F.topZ - 3.6, 24, 1, true), stem);
      tube.position.y = 3.6 + (F.topZ - 3.6) / 2;                         // retrieval opening at the bottom
      fg.add(tube);
      const ring = mesh(new T.TorusGeometry(F.openD / 2 + 0.4, 0.45, 10, 28), petal);
      ring.rotation.x = Math.PI / 2; ring.position.y = F.topZ;
      fg.add(ring);
      const back = mesh(new T.CylinderGeometry(F.outerD / 2, F.outerD / 2, F.backstop, 24, 1, true, 0, Math.PI), petal);
      back.position.y = F.topZ + F.backstop / 2;
      back.rotation.y = f.wall > 0 ? Math.PI : 0;                          // backstop on the wall side
      fg.add(back);
      const foot = mesh(new T.CylinderGeometry(F.outerD / 2 + 0.3, F.outerD / 2 + 0.3, 0.4, 24), stem);
      foot.position.y = 0.2;
      fg.add(foot);
      g.add(fg);
    }
    // LOADING ZONES and GARDENS: tape on the floor, with a light tint inside the loading zone
    for (const t of B.tapes) {
      const m = mesh(new T.BoxGeometry(t.w, 0.06, t.d), new T.MeshStandardMaterial({ color: new T.Color(t.rgb[0], t.rgb[1], t.rgb[2]), roughness: 0.8 }), false);
      m.position.copy(P(t.x, t.y, 0.03));
      g.add(m);
    }
    for (const z of B.loadingZones) {
      const tint = mesh(new T.PlaneGeometry(z.w, z.d), new T.MeshBasicMaterial({ color: z.alliance === 'red' ? 0xd83a3f : 0x2f6fd6, transparent: true, opacity: 0.18, depthWrite: false }), false);
      tint.rotation.x = -Math.PI / 2;
      tint.position.copy(P(z.x, z.y, 0.02));
      g.add(tint);
    }
    // live POLLEN: one instanced mesh, positioned every frame from the game state
    const balls = new T.InstancedMesh(new T.SphereGeometry(F.pollenD / 2, 16, 12), pollenMat, 96);
    balls.castShadow = true; balls.count = 0;
    balls.frustumCulled = false;
    g.add(balls);
    this.ballMesh = balls;
    this.scene.add(g);
  }
  /* snap = game snapshot { balls: Float32Array (x,y,z,state)*, angles: [deg per hive] }; state 1 = held by the robot */
  updateGame(snap, pose) {
    if (!this.gameGroup || !snap) { if (this.ballMesh) this.ballMesh.count = 0; return; }
    snap.angles.forEach((a, i) => { if (this.hiveGroups[i]) this.hiveGroups[i].rotation.x = a * Math.PI / 180; });
    const m = this.ballMesh, M = new T.Matrix4(), n = snap.balls.length / 4;
    const r = FTC.BIOBUZZ.flower.pollenD / 2;
    let k = 0, held = 0;
    const H = this.cfg ? this.cfg.robotHeight : 14;
    for (let i = 0; i < n && k < 96; i++) {
      let x = snap.balls[i * 4], y = snap.balls[i * 4 + 1], z = snap.balls[i * 4 + 2];
      if (snap.balls[i * 4 + 3] === 1) {
        if (!pose) continue;
        // ride on top of the robot in a row, so you can see what it is holding
        const lx = -3 + held * (2 * r + 0.2) - 1.5 * r, c = Math.cos(pose.h), s = Math.sin(pose.h);
        x = pose.x + lx * c; y = pose.y + lx * s; z = H + r - 0.5;
        held++;
      }
      M.makeTranslation(x, z, -y);
      m.setMatrixAt(k++, M);
    }
    m.count = k;
    m.instanceMatrix.needsUpdate = true;
  }
  setStart(cfg) {
    const L = cfg.robotLength / 2, W = cfg.robotWidth / 2, h = cfg.start.h * Math.PI / 180;
    const c = Math.cos(h), s = Math.sin(h);
    const pts = [[L, W], [L, -W], [-L, -W], [-L, W], [L, W]].map(([a, b]) => new T.Vector3(cfg.start.x + a * c - b * s, 0.08, -(cfg.start.y + a * s + b * c)));
    this.startOutline.geometry.setFromPoints(pts);
    this.startOutline.computeLineDistances();
  }
  setObstacles(list) {
    while (this.obstacleGroup.children.length) this.obstacleGroup.remove(this.obstacleGroup.children[0]);
    const m = new T.MeshStandardMaterial({ color: 0x7a5c3a, roughness: 0.8 });
    for (const o of list || []) {
      const b = new T.Mesh(new T.BoxGeometry(o.w, o.h || 6, o.d), m);
      b.position.set(o.x, (o.h || 6) / 2, -o.y); b.castShadow = b.receiveShadow = true;
      this.obstacleGroup.add(b);
    }
  }

  /* ---------- robot model */
  buildRobot(cfg, devices) {
    if (this.robot) this.scene.remove(this.robot);
    const R = new T.Group();
    this.robot = R;
    const L = cfg.robotLength, W = cfg.robotWidth, H = cfg.robotHeight;
    const al = new T.MeshStandardMaterial({ color: 0xaeb4bb, metalness: 0.55, roughness: 0.38 });
    const dark = new T.MeshStandardMaterial({ color: 0x2b2f35, roughness: 0.7 });
    const plate = new T.MeshStandardMaterial({ color: 0x3a3f46, roughness: 0.6, metalness: 0.2 });
    const add = (geo, mat, x, y, z, parent = R) => { const m = new T.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = true; m.receiveShadow = true; parent.add(m); return m; };
    const r = cfg.wheelDiameter / 2;
    const yAxle = r;
    // side channels and cross members
    for (const s of [-1, 1]) add(new T.BoxGeometry(L, 1.5, 1.5), al, 0, yAxle + 0.6, s * (W / 2 - 0.75));
    for (const s of [-1, 1]) add(new T.BoxGeometry(1.5, 1.5, W - 3), al, s * (L / 2 - 0.75), yAxle + 0.6, 0);
    add(new T.BoxGeometry(L - 3, 0.25, W - 3), plate, 0, yAxle + 1.45, 0);
    // upper deck and hub
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) add(new T.BoxGeometry(1, H - yAxle - 2, 1), al, sx * (L / 2 - 2), (H + yAxle) / 2, sz * (W / 2 - 2));
    for (const sz of [-1, 1]) add(new T.BoxGeometry(L - 3, 1, 1), al, 0, H - 0.5, sz * (W / 2 - 2));
    const hub = add(new T.BoxGeometry(5.6, 1.2, 4.2), new T.MeshStandardMaterial({ color: 0x1e2125, roughness: 0.5 }), -L / 2 + 5, yAxle + 2.2, 0);
    add(new T.BoxGeometry(0.5, 0.2, 0.5), new T.MeshBasicMaterial({ color: 0x4ade80 }), 0.2, 0.7, 1.2, hub);
    add(new T.BoxGeometry(3.6, 1.6, 2.2), new T.MeshStandardMaterial({ color: 0x1f6f3a, roughness: 0.6 }), -L / 2 + 4.5, yAxle + 2.4, -W / 2 + 3.5);
    // front bumper in accent colour marks the front of the robot
    this.frontBar = add(new T.BoxGeometry(0.8, 2.2, W - 1), new T.MeshStandardMaterial({ color: this.accent || 0xf2b230, roughness: 0.5 }), L / 2 + 0.2, yAxle + 0.6, 0);
    add(new T.ConeGeometry(1.2, 2.8, 3), new T.MeshStandardMaterial({ color: this.accent || 0xf2b230 }), L / 2 - 3, H - 0.1, 0).rotation.set(-Math.PI / 2, 0, -Math.PI / 2);
    // wheels
    const drive = FTC.effectiveDrive(cfg, devices.map(d => d.name));
    this.wheels = {};
    const wp = { FL: [cfg.wheelBase / 2, cfg.trackWidth / 2], FR: [cfg.wheelBase / 2, -cfg.trackWidth / 2], BL: [-cfg.wheelBase / 2, cfg.trackWidth / 2], BR: [-cfg.wheelBase / 2, -cfg.trackWidth / 2] };
    for (const [role, [lx, ly]] of Object.entries(wp)) {
      const flip = role === 'FL' || role === 'BR';
      const tex = wheelTexture(drive === 'mecanum', flip);
      const piv = new T.Group();
      piv.position.set(lx, yAxle, -ly);
      const wm = new T.Mesh(new T.CylinderGeometry(r, r, 1.5, 28), [new T.MeshStandardMaterial({ map: tex, roughness: 0.8 }), new T.MeshStandardMaterial({ color: 0x8e949c, metalness: 0.5, roughness: 0.4 }), new T.MeshStandardMaterial({ color: 0x8e949c, metalness: 0.5, roughness: 0.4 })]);
      wm.rotation.x = Math.PI / 2;
      wm.castShadow = true;
      piv.add(wm);
      R.add(piv);
      this.wheels[role] = piv;
    }
    this.buildMechanisms(cfg, devices);
    this.scene.add(R);
    this.cfg = cfg;
  }
  buildMechanisms(cfg, devices) {
    this.mechs = [];
    this.beams.forEach(b => this.scene.remove(b.line));
    this.beams = [];
    const R = this.robot;
    const L = cfg.robotLength, W = cfg.robotWidth, H = cfg.robotHeight;
    const al = new T.MeshStandardMaterial({ color: 0xc3c8ce, metalness: 0.55, roughness: 0.35 });
    const acc = new T.MeshStandardMaterial({ color: 0xe8e1d2, roughness: 0.5 });
    const servoMat = new T.MeshStandardMaterial({ color: 0x15171a, roughness: 0.6 });
    const roll = new T.MeshStandardMaterial({ color: 0x3f7f5a, roughness: 0.6 });
    let endEffector = null;
    const list = devices.filter(d => d.kind === 'motor' && !['FL', 'FR', 'BL', 'BR', 'L', 'R'].includes(d.role) || d.kind === 'servo' || d.kind === 'crservo');
    let laneZ = 0;
    const lanes = [0, -4, 4, -7, 7];
    const nextLane = () => lanes[(laneZ++) % lanes.length];
    // pass 1: arms and lifts (they can carry a claw)
    for (const d of list) {
      if (d.viz === 'arm') {
        const z = nextLane();
        const piv = new T.Group(); piv.position.set(-L / 2 + 3, H + 1.2, z);
        const link = new T.Mesh(new T.BoxGeometry(16, 1.2, 1.2), al); link.position.x = 8; link.castShadow = true;
        const hubm = new T.Mesh(new T.CylinderGeometry(1.4, 1.4, 1.8, 16), servoMat); hubm.rotation.x = Math.PI / 2;
        const tip = new T.Group(); tip.position.x = 16;
        piv.add(link, hubm, tip);
        R.add(piv);
        const m = { name: d.name, type: 'arm', obj: piv, gear: d.gear || 1, tpr: (FTC.MOTORS[d.motor] || FTC.MOTORS['gobilda-312']).tpr, tip };
        this.mechs.push(m);
        if (!endEffector) endEffector = tip;
      } else if (d.viz === 'lift') {
        const z = nextLane();
        const base = new T.Group(); base.position.set(-1, H, z);
        const mast = new T.Mesh(new T.BoxGeometry(1.2, 16, 1.2), al); mast.position.y = 8; mast.castShadow = true;
        const stage = new T.Mesh(new T.BoxGeometry(1, 16, 1), new T.MeshStandardMaterial({ color: 0xd9dde2, metalness: 0.5, roughness: 0.3 })); stage.position.set(0.9, 8, 0); stage.castShadow = true;
        const carriage = new T.Group(); carriage.position.set(2, 2, 0);
        const cplate = new T.Mesh(new T.BoxGeometry(1, 3, 4), acc); cplate.castShadow = true; carriage.add(cplate);
        const tip = new T.Group(); tip.position.set(2.5, 0, 0); carriage.add(tip);
        base.add(mast, stage, carriage);
        R.add(base);
        this.mechs.push({ name: d.name, type: 'lift', obj: base, stage, carriage, tpr: (FTC.MOTORS[d.motor] || FTC.MOTORS['gobilda-312']).tpr, spool: d.spool || 4.7 });
        if (!endEffector) endEffector = tip;
      }
    }
    // pass 2: rollers, servos, claws
    let spinCount = 0, servoCount = 0;
    for (const d of list) {
      if (d.viz === 'spin') {
        const g = new T.Group();
        g.position.set(L / 2 + 1.6, 3.2 + spinCount * 3.6, 0);
        const cyl = new T.Mesh(new T.CylinderGeometry(1.4, 1.4, W - 4, 20), roll); cyl.rotation.x = Math.PI / 2; cyl.castShadow = true;
        const stripe = new T.Mesh(new T.BoxGeometry(0.4, 0.4, W - 3.8), new T.MeshBasicMaterial({ color: 0xe6f0e9 })); stripe.position.y = 1.35;
        const spinner = new T.Group(); spinner.add(cyl, stripe);
        g.add(spinner);
        R.add(g);
        this.mechs.push({ name: d.name, type: 'spin', obj: spinner, kind: d.kind, tpr: d.kind === 'motor' ? (FTC.MOTORS[d.motor] || FTC.MOTORS['gobilda-312']).tpr : 1 });
        spinCount++;
      } else if (d.viz === 'claw') {
        const g = new T.Group();
        const parent = endEffector || R;
        if (!endEffector) g.position.set(L / 2 + 1, H - 2, 0);
        const palm = new T.Mesh(new T.BoxGeometry(1.2, 1.2, 5), servoMat); palm.castShadow = true;
        const fa = new T.Mesh(new T.BoxGeometry(4, 0.8, 0.6), acc); const fb = fa.clone();
        fa.castShadow = fb.castShadow = true;
        fa.position.set(2.2, 0, 1.6); fb.position.set(2.2, 0, -1.6);
        g.add(palm, fa, fb);
        parent.add(g);
        this.mechs.push({ name: d.name, type: 'claw', obj: g, fa, fb });
      } else if (d.viz === 'servo') {
        const g = new T.Group();
        g.position.set(L / 2 - 3, H + 0.6, (servoCount % 2 ? -1 : 1) * (W / 2 - 2.5));
        const body = new T.Mesh(new T.BoxGeometry(1.6, 1.6, 0.8), servoMat);
        const horn = new T.Group();
        const hm = new T.Mesh(new T.BoxGeometry(5, 0.4, 0.6), acc); hm.position.x = 2.5; hm.castShadow = true;
        horn.add(hm); horn.position.y = 1;
        g.add(body, horn);
        R.add(g);
        this.mechs.push({ name: d.name, type: 'servo', obj: horn });
        servoCount++;
      }
    }
    // distance sensor beams
    for (const d of devices) {
      if (d.kind === 'sensor' && d.sensorKind === 'distance') {
        const geo = new T.BufferGeometry().setFromPoints([new T.Vector3(), new T.Vector3()]);
        const line = new T.Line(geo, new T.LineBasicMaterial({ color: 0xff5a5f, transparent: true, opacity: 0.85 }));
        const dot = new T.Mesh(new T.SphereGeometry(0.7, 10, 8), new T.MeshBasicMaterial({ color: 0xff5a5f }));
        line.add(dot);
        this.scene.add(line);
        this.beams.push({ name: d.name, line, dot, mount: d.mount || 'front' });
      }
    }
  }
  /* state = { x, y, h, dev: Map(name -> [a, b, c]) } */
  update(state, sim) {
    if (!this.robot || !state) return;
    const R = this.robot, cfg = this.cfg;
    R.position.set(state.x, 0, -state.y);
    R.rotation.y = state.h;
    // wheels
    if (sim) {
      for (const [name, dev] of sim.devices) {
        if (!dev.$cfg || !dev.$cfg.isDrive) continue;
        const role = dev.$cfg.role;
        const tgt = role === 'L' ? ['FL', 'BL'] : role === 'R' ? ['FR', 'BR'] : [role];
        const st = state.dev.get(name);
        if (!st) continue;
        const left = role === 'FL' || role === 'BL' || role === 'L';
        const side = left && cfg.mirrorLeft ? -1 : 1;
        const ang = side * st[0] / dev.$cfg.tpr * 2 * Math.PI;
        for (const r of tgt) if (this.wheels[r]) this.wheels[r].rotation.z = -ang;
      }
    }
    for (const m of this.mechs) {
      const st = state.dev.get(m.name);
      if (!st) continue;
      if (m.type === 'arm') m.obj.rotation.z = (-25 + st[0] / m.tpr * 360 / m.gear) * Math.PI / 180;
      else if (m.type === 'lift') {
        const ext = Math.max(0, Math.min(34, st[0] / m.tpr * m.spool));
        m.stage.position.y = 8 + ext * 0.5;
        m.carriage.position.y = 2 + ext;
      } else if (m.type === 'spin') m.obj.rotation.z = -(m.kind === 'motor' ? st[0] / m.tpr * 2 * Math.PI : st[0]);
      else if (m.type === 'claw') { const open = st[1] ? st[0] : 0.5; m.fa.position.z = 0.6 + open * 2.2; m.fb.position.z = -(0.6 + open * 2.2); }
      else if (m.type === 'servo') m.obj.rotation.z = ((st[1] ? st[0] : 0.5) - 0.5) * Math.PI;
    }
    if (sim) {
      for (const b of this.beams) {
        const cfgS = { mount: b.mount };
        const saved = sim.robot;
        sim.robot = { x: state.x, y: state.y, h: state.h };
        const p = sim.sensorPose(cfgS);
        const d = Math.min(sim.raycast(cfgS), 78.74);
        sim.robot = saved;
        const pos = b.line.geometry.attributes.position;
        const ex = p.x + Math.cos(p.a) * d, ez = -(p.y + Math.sin(p.a) * d);
        pos.setXYZ(0, p.x, 3, -p.y); pos.setXYZ(1, ex, 3, ez); pos.needsUpdate = true;
        b.line.geometry.computeBoundingSphere();
        b.dot.position.set(ex, 3, ez);
      }
    }
    if (this.cam.mode === 'follow') {
      this.cam.target.lerp(new T.Vector3(state.x, 6, -state.y), 0.15);
    }
  }
  setTrail(points) {
    if (this.trailLine) { this.scene.remove(this.trailLine); this.trailLine.geometry.dispose(); }
    if (!points || points.length < 2) { this.trailLine = null; return; }
    const arr = new Float32Array(points.length * 3);
    points.forEach((p, i) => { arr[i * 3] = p[0]; arr[i * 3 + 1] = 0.18; arr[i * 3 + 2] = -p[1]; });
    const g = new T.BufferGeometry();
    g.setAttribute('position', new T.BufferAttribute(arr, 3));
    this.trailLine = new T.Line(g, new T.LineBasicMaterial({ color: this.accent, transparent: true, opacity: 0.9 }));
    this.scene.add(this.trailLine);
  }

  /* ---------- camera */
  setCameraMode(mode) {
    this.cam.mode = mode;
    const c = this.cam;
    if (mode === 'top') { c.theta = -Math.PI / 2; c.phi = 0.001; c.radius = 240; c.target.set(0, 0, 0); }
    else if (mode === 'orbit') { c.theta = -Math.PI / 2 - 0.35; c.phi = 0.95; c.radius = 230; c.target.set(0, 0, 0); }
    else if (mode === 'driver') { c.theta = -Math.PI / 2; c.phi = 1.18; c.radius = 175; c.target.set(0, 0, -6); }
    else if (mode === 'follow') { c.phi = 0.85; c.radius = 90; if (this.robot) c.target.copy(this.robot.position); }
  }
  bindControls() {
    const el = this.renderer.domElement;
    el.style.touchAction = 'none';
    const ptrs = new Map();
    let last = null, pinch = null;
    const ground = e => {
      const b = el.getBoundingClientRect();
      const ndc = new T.Vector2(((e.clientX - b.left) / b.width) * 2 - 1, -((e.clientY - b.top) / b.height) * 2 + 1);
      const ray = new T.Raycaster(); ray.setFromCamera(ndc, this.camera);
      const p = new T.Vector3();
      return ray.ray.intersectPlane(new T.Plane(new T.Vector3(0, 1, 0), 0), p) ? { x: p.x, y: -p.z } : null;
    };
    el.addEventListener('pointerdown', e => {
      el.setPointerCapture(e.pointerId);
      ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY, b: e.button, shift: e.shiftKey, place: !!this.onPlace && e.button === 0 && !e.shiftKey });
      last = { x: e.clientX, y: e.clientY };
      if (this.onPlace && e.button === 0 && !e.shiftKey) { const g = ground(e); if (g) this.onPlace(g); }
    });
    el.addEventListener('pointermove', e => {
      if (!ptrs.has(e.pointerId)) return;
      if (ptrs.get(e.pointerId).place && this.onPlace && ptrs.size === 1) { const g = ground(e); if (g) this.onPlace(g); return; }
      const p = ptrs.get(e.pointerId);
      const dx = e.clientX - p.x, dy = e.clientY - p.y;
      p.x = e.clientX; p.y = e.clientY;
      if (ptrs.size === 2) {
        const [a, b] = [...ptrs.values()];
        const dist = Math.hypot(a.x - b.x, a.y - b.y);
        if (pinch) this.zoom(pinch / dist);
        pinch = dist;
        return;
      }
      if (p.b === 2 || p.shift) this.pan(dx, dy);
      else { this.cam.theta -= dx * 0.008; this.cam.phi = Math.min(1.5, Math.max(0.001, this.cam.phi - dy * 0.006)); }
    });
    const up = e => { ptrs.delete(e.pointerId); if (ptrs.size < 2) pinch = null; };
    el.addEventListener('pointerup', up);
    el.addEventListener('pointercancel', up);
    el.addEventListener('contextmenu', e => e.preventDefault());
    el.addEventListener('wheel', e => { e.preventDefault(); this.zoom(Math.exp(e.deltaY * 0.0012)); }, { passive: false });
  }
  zoom(f) { this.cam.radius = Math.min(700, Math.max(25, this.cam.radius * f)); }
  pan(dx, dy) {
    const c = this.cam, s = c.radius * 0.0018;
    const right = new T.Vector3(-Math.sin(c.theta), 0, -Math.cos(c.theta));
    const fwd = new T.Vector3(-Math.cos(c.theta), 0, Math.sin(c.theta));
    c.target.addScaledVector(right, -dx * s).addScaledVector(fwd, dy * s);
    if (c.mode === 'follow') c.mode = 'orbit';
  }
  resize() {
    const w = this.host.clientWidth || 300, h = this.host.clientHeight || 200;
    this.renderer.setSize(w, h, false);
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }
  render() {
    const c = this.cam;
    const sp = Math.sin(c.phi);
    this.camera.position.set(c.target.x + c.radius * sp * Math.cos(c.theta), c.target.y + c.radius * Math.cos(c.phi), c.target.z - c.radius * sp * Math.sin(c.theta));
    this.camera.up.set(0, 1, 0);
    if (c.phi < 0.01) this.camera.up.set(0, 0, -1);
    this.camera.lookAt(c.target);
    this.renderer.render(this.scene, this.camera);
  }
}
FTC.Scene = Scene;
})(typeof globalThis !== 'undefined' ? globalThis : window);
