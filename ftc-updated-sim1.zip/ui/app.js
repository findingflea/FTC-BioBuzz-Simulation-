/* Main controller: editor, compile, run modes, playback, panels. */
(function (G) {
'use strict';
const FTC = G.FTC;
const $ = s => document.querySelector(s);
const el = (tag, cls, txt) => { const e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; };
const store = {
  get(k) { try { return G.localStorage.getItem('ftcsim.' + k); } catch (e) { return null; } },
  set(k, v) { try { G.localStorage.setItem('ftcsim.' + k, v); } catch (e) { /* storage blocked */ } },
};
const fmtT = t => (t < 0 ? '-' : '') + Math.floor(Math.abs(t) / 60) + ':' + String(Math.floor(Math.abs(t) % 60)).padStart(2, '0');
const START_PRESETS = [
  { label: 'South wall · left tile', x: -36, y: -61, h: 90 },
  { label: 'South wall · right tile', x: 36, y: -61, h: 90 },
  { label: 'Red wall · lower tile', x: -61, y: -36, h: 0 },
  { label: 'Red wall · upper tile', x: -61, y: 36, h: 0 },
  { label: 'Blue wall · lower tile', x: 61, y: -36, h: 180 },
  { label: 'Blue wall · upper tile', x: 61, y: 36, h: 180 },
  { label: 'Field center', x: 0, y: 0, h: 90 },
];
const JOBS = [['intake', 'Intake (picks up POLLEN)'], ['shooter', 'Shooter / flywheel'], ['feeder', 'Feeder (pushes POLLEN into the shooter)'], ['none', 'Not used for POLLEN']];
const ROLE_LABEL = { FL: 'Front left', FR: 'Front right', BL: 'Back left', BR: 'Back right', L: 'Left side', R: 'Right side', none: 'Not a drive motor' };

const App = {
  cfg: null, compiled: null, opIdx: 0, sim: null, mode: 'idle', cursor: 0, playing: false, speed: 1, lastWall: 0,
  settle: 0, panelTick: 0, trailTick: 0, logCount: -1, logCursorKey: '', devRowsFor: null,

  init() {
    this.cfg = this.loadCfg();
    try { this.scene = new FTC.Scene($('#viewport')); }
    catch (e) {
      console.error(e);
      this.scene = { applyTheme() {}, buildRobot() {}, setStart() {}, setObstacles() {}, setGame() {}, updateGame() {}, update() {}, setTrail() {}, render() {}, setCameraMode() {} };
      this.no3d = 'The 3D view could not start on this device (WebGL is unavailable). Telemetry, devices and the console still work.';
    }
    this.gp = new FTC.GamepadPanel($('#gamepad'));
    const code = store.get('code') || FTC.EXAMPLES[0].code;
    $('#code').value = code;
    this.fillExamples();
    this.bindEditor();
    this.bindControls();
    this.buildRobotForm();
    this.watchTheme();
    this.compileNow(true);
    this.rebuildRobot();
    this.scene.setStart(this.cfg);
    this.scene.setObstacles(this.cfg.obstacles);
    this.scene.setGame(this.cfg.field);
    requestAnimationFrame(t => this.frame(t));
    // open with a finished run so the first view shows the robot moving
    this.initMatchUI();
    if (this.compiled && this.currentOp() && this.currentOp().type === 'Autonomous') this.runAuton(true);
    else this.showIdleState();
  },
  loadCfg() {
    const d = FTC.defaultConfig();
    try { const s = JSON.parse(store.get('cfg') || 'null'); if (s && typeof s === 'object') return Object.assign(d, s, { start: Object.assign(d.start, s.start || {}) }); } catch (e) { /* ignore */ }
    return d;
  },
  saveCfg() { store.set('cfg', JSON.stringify(this.cfg)); },
  currentOp() { return this.compiled && this.compiled.opModes[this.opIdx]; },

  /* ---------------- editor */
  fillExamples() {
    const s = $('#exampleSel');
    for (const ex of FTC.EXAMPLES) { const o = el('option', null, ex.title); o.value = ex.id; s.appendChild(o); }
    s.addEventListener('change', () => {
      const ex = FTC.EXAMPLES.find(e => e.id === s.value);
      s.value = '';
      if (!ex) return;
      $('#code').value = ex.code;
      store.set('code', ex.code);
      this.updateGutter();
      this.hardStop();
      this.compileNow(true);
      this.rebuildRobot();
      if (this.currentOp() && this.currentOp().type === 'Autonomous') this.runAuton(true); else this.showIdleState();
    });
  },
  bindEditor() {
    const ta = $('#code');
    let timer = null;
    ta.addEventListener('input', () => {
      this.updateGutter();
      store.set('code', ta.value);
      clearTimeout(timer);
      timer = setTimeout(() => { this.compileNow(false); this.rebuildRobot(); }, 650);
    });
    ta.addEventListener('scroll', () => { $('#gutter').scrollTop = ta.scrollTop; this.placeErrLine(); });
    ta.addEventListener('keydown', e => {
      if (e.key === 'Tab' && !e.shiftKey) {
        e.preventDefault();
        const s = ta.selectionStart, en = ta.selectionEnd;
        ta.setRangeText('    ', s, en, 'end');
        ta.dispatchEvent(new Event('input'));
      } else if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        const op = this.compileNow(true) && this.currentOp();
        if (op && op.type === 'Autonomous') this.runAuton(true); else this.initLive();
      }
    });
    this.updateGutter();
  },
  updateGutter() {
    const n = $('#code').value.split('\n').length;
    const g = $('#gutter');
    if (g.childElementCount !== n) {
      let s = '';
      for (let i = 1; i <= n; i++) s += i + '\n';
      g.textContent = s;
    }
  },
  gotoLine(line) {
    const ta = $('#code');
    const lines = ta.value.split('\n');
    let pos = 0;
    for (let i = 0; i < line - 1 && i < lines.length; i++) pos += lines[i].length + 1;
    this.showTab('code');
    ta.focus();
    ta.setSelectionRange(pos, pos + (lines[line - 1] || '').length);
    const lh = parseFloat(getComputedStyle(ta).lineHeight) || 19;
    ta.scrollTop = Math.max(0, (line - 4) * lh);
    this.errLine = line;
    this.placeErrLine();
  },
  placeErrLine() {
    const m = $('#errLine');
    if (!this.errLine) { m.hidden = true; return; }
    const ta = $('#code');
    const lh = parseFloat(getComputedStyle(ta).lineHeight) || 19;
    const pt = parseFloat(getComputedStyle(ta).paddingTop) || 10;
    m.hidden = false;
    m.style.transform = `translateY(${pt + (this.errLine - 1) * lh - ta.scrollTop}px)`;
    m.style.height = lh + 'px';
  },
  setError(err) {
    const box = $('#errBox');
    if (!err) { box.hidden = true; this.errLine = null; this.placeErrLine(); return; }
    box.hidden = false;
    box.innerHTML = '';
    const head = el('div', 'err-head');
    head.appendChild(el('b', null, err.title));
    if (err.line) {
      const b = el('button', 'linkbtn', `Line ${err.line}`);
      b.type = 'button';
      b.addEventListener('click', () => this.gotoLine(err.line));
      head.appendChild(b);
    }
    box.appendChild(head);
    box.appendChild(el('div', 'err-msg', err.message));
    if (err.hint) box.appendChild(el('div', 'err-hint', err.hint));
    this.errLine = err.line || null;
    this.placeErrLine();
  },
  compileNow(force) {
    const src = $('#code').value;
    const msg = $('#compileMsg');
    try {
      const c = FTC.compileJava(src);
      if (!c.opModes.length) throw Object.assign(new Error('No OpMode found. Your class must extend LinearOpMode or OpMode.'), { name: 'CompileError', line: 1 });
      const prevName = this.currentOp() && this.currentOp().className;
      this.compiled = c;
      const idx = c.opModes.findIndex(o => o.className === prevName);
      this.opIdx = idx >= 0 ? idx : Math.max(0, c.opModes.findIndex(o => !o.disabled));
      for (const d of FTC.prescanDevices(src)) FTC.ensureDevice(this.cfg, d.name, d.type);
      this.saveCfg();
      this.fillOpModes();
      const devs = FTC.prescanDevices(src);
      msg.className = 'msg ok';
      msg.textContent = `Compiled · ${devs.length} device${devs.length === 1 ? '' : 's'} found`;
      const unsupported = c.imports.filter(i => /acmerobotics\.roadrunner|pedropathing|com\.arcrobotics|ftclib|org\.openftc|limelight/i.test(i));
      if (unsupported.length) { msg.className = 'msg warn'; msg.textContent = 'Compiled · some libraries are not simulated'; }
      this.setError(null);
      if (c.warnings.length) this.setError({ title: 'Heads up', message: c.warnings.map(w => `Line ${w.line}: ${w.msg}`).join('\n'), line: c.warnings[0].line });
      if (unsupported.length) this.setError({ title: 'Libraries the simulator does not run', message: unsupported.join('\n'), hint: 'Road Runner, Pedro Pathing, FTCLib, EasyOpenCV and Limelight are not simulated. The core FTC SDK, goBILDA Pinpoint and SparkFun OTOS are.' });
      return c;
    } catch (e) {
      this.compiled = null;
      this.fillOpModes();
      msg.className = 'msg bad';
      const kind = e.name === 'JavaSyntaxError' ? 'Syntax error' : e.name === 'CompileError' ? 'Compile error' : 'Error';
      msg.textContent = kind + (e.line ? ` on line ${e.line}` : '');
      this.setError({ title: kind, message: e.message, line: e.line });
      if (force && !e.line) console.error(e);
      return null;
    }
  },
  fillOpModes() {
    const s = $('#opmode');
    s.innerHTML = '';
    if (!this.compiled) { const o = el('option', null, 'Fix the code to choose an OpMode'); s.appendChild(o); s.disabled = true; this.updateButtons(); return; }
    s.disabled = this.compiled.opModes.length < 2;
    this.compiled.opModes.forEach((op, i) => { const o = el('option', null, `${op.name}${op.disabled ? ' (disabled)' : ''}`); o.value = i; s.appendChild(o); });
    s.value = this.opIdx;
    this.updateButtons();
  },

  /* ---------------- robot + hardware panels */
  rebuildRobot() {
    const used = this.usedDeviceNames();
    const devs = Object.entries(this.cfg.devices).filter(([name]) => used.has(name)).map(([name, d]) => Object.assign({ name }, d));
    const key = JSON.stringify([this.cfg.robotLength, this.cfg.robotWidth, this.cfg.robotHeight, this.cfg.trackWidth, this.cfg.wheelBase, this.cfg.wheelDiameter, this.cfg.drive, devs]);
    if (key !== this.robotKey) { this.robotKey = key; this.scene.buildRobot(this.cfg, devs); }
    this.buildHardwareTable();
    if (this.mode === 'idle') this.scene.update({ x: this.cfg.start.x, y: this.cfg.start.y, h: this.cfg.start.h * Math.PI / 180, dev: new Map() }, null);
  },
  usedDeviceNames() {
    const src = $('#code').value;
    const names = new Set(FTC.prescanDevices(src).map(d => d.name));
    if (this.sim) for (const n of this.sim.devices.keys()) names.add(n);
    if (this.playMode === 'match' && this.matchCodeNames) for (const n of this.matchCodeNames) names.add(n);
    return names;
  },
  buildHardwareTable() {
    const host = $('#hwTable');
    const used = this.usedDeviceNames();
    const entries = Object.entries(this.cfg.devices).filter(([n]) => used.has(n));
    host.innerHTML = '';
    if (!entries.length) { host.appendChild(el('p', 'empty', 'No hardware yet. Devices appear here once your code calls hardwareMap.get(...).')); return; }
    const mkSel = (opts, val, on) => { const s = el('select'); for (const [v, l] of opts) { const o = el('option', null, l); o.value = v; s.appendChild(o); } s.value = val == null ? '' : val; s.addEventListener('change', () => on(s.value)); return s; };
    const changed = () => { this.saveCfg(); this.robotKey = null; this.rebuildRobot(); };
    for (const [name, d] of entries) {
      const row = el('div', 'hw-row');
      const id = el('div', 'hw-id');
      id.appendChild(el('code', null, name));
      id.appendChild(el('span', 'hw-type', d.type));
      row.appendChild(id);
      const ctl = el('div', 'hw-ctl');
      const field = (label, node) => { const f = el('label', 'fld'); f.appendChild(el('span', null, label)); f.appendChild(node); ctl.appendChild(f); };
      if (d.kind === 'motor') {
        field('Role', mkSel(Object.entries(ROLE_LABEL), d.role, v => { d.role = v; changed(); }));
        field('Motor', mkSel(Object.entries(FTC.MOTORS).map(([k, m]) => [k, m.label]), d.motor, v => { d.motor = v; changed(); }));
        if (!['FL', 'FR', 'BL', 'BR', 'L', 'R'].includes(d.role)) {
          field('Shows as', mkSel([['arm', 'Arm (rotates)'], ['lift', 'Lift / slide'], ['spin', 'Roller / intake'], ['none', 'Hidden']], d.viz, v => { d.viz = v; changed(); }));
          const stop = (label, key) => {
            const i = el('input'); i.type = 'number'; i.placeholder = 'none'; i.id = `hw-${name}-${key}`.replace(/\W+/g, '-');
            i.value = d[key] == null ? '' : d[key];
            i.addEventListener('change', () => { const v = i.value.trim() === '' ? null : parseFloat(i.value); d[key] = Number.isFinite(v) ? v : null; this.saveCfg(); $('#rerunHint').hidden = this.mode !== 'replay'; });
            field(label, i);
          };
          field('Game job', mkSel(JOBS, d.job || 'none', v => { d.job = v; changed(); }));
          stop('Hard stop low (ticks)', 'min');
          stop('Hard stop high (ticks)', 'max');
        }
      } else if (d.kind === 'servo') {
        field('Shows as', mkSel([['claw', 'Claw'], ['servo', 'Servo arm'], ['none', 'Hidden']], d.viz, v => { d.viz = v; changed(); }));
        field('Game job', mkSel([['feeder', 'Feeder (pushes POLLEN into the shooter)'], ['none', 'Not used for POLLEN']], d.job || 'none', v => { d.job = v; changed(); }));
      } else if (d.kind === 'crservo') {
        field('Shows as', mkSel([['spin', 'Roller / intake'], ['none', 'Hidden']], d.viz, v => { d.viz = v; changed(); }));
        field('Game job', mkSel(JOBS, d.job || 'none', v => { d.job = v; changed(); }));
      } else if (d.kind === 'sensor') {
        field('Faces', mkSel([['front', 'Front'], ['back', 'Back'], ['left', 'Left'], ['right', 'Right']], d.mount, v => { d.mount = v; changed(); }));
      } else ctl.appendChild(el('span', 'hw-note', d.kind === 'imu' ? 'Reads the robot heading (counter-clockwise is positive)' : d.kind === 'odometry' ? 'Reads the true pose from where it was reset' : 'Simulated with default values'));
      row.appendChild(ctl);
      host.appendChild(row);
    }
  },
  buildRobotForm() {
    const c = this.cfg;
    const f = $('#robotForm');
    f.innerHTML = '';
    const sec = t => { const s = el('fieldset'); s.appendChild(el('legend', null, t)); f.appendChild(s); return s; };
    const num = (parent, label, get, set, opts = {}) => {
      const l = el('label', 'fld');
      l.appendChild(el('span', null, label));
      const i = el('input'); i.type = 'number'; i.step = opts.step || 'any'; if (opts.min != null) i.min = opts.min; if (opts.max != null) i.max = opts.max;
      i.id = 'cfg-' + label.replace(/\W+/g, '-').toLowerCase();
      i.value = get();
      i.addEventListener('change', () => { const v = parseFloat(i.value); if (Number.isFinite(v)) { set(v); this.cfgChanged(); } else i.value = get(); });
      l.appendChild(i);
      if (opts.unit) l.appendChild(el('em', null, opts.unit));
      parent.appendChild(l);
      return i;
    };
    const sel = (parent, label, opts, get, set) => {
      const l = el('label', 'fld'); l.appendChild(el('span', null, label));
      const s = el('select'); s.id = 'cfg-' + label.replace(/\W+/g, '-').toLowerCase();
      for (const [v, t] of opts) { const o = el('option', null, t); o.value = v; s.appendChild(o); }
      s.value = get();
      s.addEventListener('change', () => { set(s.value); this.cfgChanged(); });
      l.appendChild(s); parent.appendChild(l); return s;
    };
    const chk = (parent, label, get, set, hint) => {
      const l = el('label', 'chk'); const i = el('input'); i.type = 'checkbox'; i.checked = get(); i.id = 'cfg-' + label.replace(/\W+/g, '-').toLowerCase();
      i.addEventListener('change', () => { set(i.checked); this.cfgChanged(); });
      l.appendChild(i); const t = el('span', null, label); l.appendChild(t);
      if (hint) l.appendChild(el('small', null, hint));
      parent.appendChild(l);
    };
    const d = sec('Drivetrain');
    sel(d, 'Drive type', [['auto', 'Detect from motor names'], ['mecanum', 'Mecanum (4 wheels)'], ['tank', 'Tank / differential']], () => c.drive, v => (c.drive = v));
    sel(d, 'Drive motors', Object.entries(FTC.MOTORS).map(([k, m]) => [k, m.label]), () => c.driveMotor, v => {
      c.driveMotor = v;
      for (const dv of Object.values(c.devices)) if (dv.kind === 'motor' && ['FL', 'FR', 'BL', 'BR', 'L', 'R'].includes(dv.role)) dv.motor = v;
    });
    sel(d, 'Wheels', [['3.78', '96 mm mecanum (3.78 in)'], ['4.09', '104 mm mecanum (4.09 in)'], ['2.95', '75 mm (2.95 in)'], ['4', '4 in traction'], ['3.54', '90 mm traction (3.54 in)']].concat(['3.78', '4.09', '2.95', '4', '3.54'].includes(String(c.wheelDiameter)) ? [] : [[String(c.wheelDiameter), `Custom (${c.wheelDiameter} in)`]]), () => String(c.wheelDiameter), v => (c.wheelDiameter = parseFloat(v)));
    chk(d, 'Left motors are mounted mirrored', () => c.mirrorLeft, v => (c.mirrorLeft = v), 'Standard build: the left side needs setDirection(REVERSE) to drive forward.');
    const g = sec('Size');
    num(g, 'Length', () => c.robotLength, v => (c.robotLength = v), { unit: 'in', min: 6, max: 24 });
    num(g, 'Width', () => c.robotWidth, v => (c.robotWidth = v), { unit: 'in', min: 6, max: 24 });
    num(g, 'Track width', () => c.trackWidth, v => (c.trackWidth = v), { unit: 'in', min: 4, max: 24 });
    num(g, 'Wheelbase', () => c.wheelBase, v => (c.wheelBase = v), { unit: 'in', min: 4, max: 24 });
    const p = sec('Performance');
    num(p, 'Top speed', () => Math.round(c.speedEff * 100), v => (c.speedEff = Math.min(1, Math.max(0.2, v / 100))), { unit: '% of free speed', min: 20, max: 100 });
    num(p, 'Strafe efficiency', () => Math.round(c.strafeEff * 100), v => (c.strafeEff = Math.min(1, Math.max(0.3, v / 100))), { unit: '%', min: 30, max: 100 });
    num(p, 'Time to full speed', () => c.accelTime, v => (c.accelTime = Math.min(2, Math.max(0.05, v))), { unit: 's', min: 0.05, max: 2, step: 0.05 });
    num(p, 'Battery', () => c.battery, v => (c.battery = v), { unit: 'V', min: 10, max: 14.5, step: 0.1 });
    const s = sec('Start position');
    const presetSel = el('select'); presetSel.id = 'cfg-start-preset';
    presetSel.appendChild(Object.assign(el('option', null, 'Choose a start…'), { value: '' }));
    START_PRESETS.forEach((ps, i) => { const o = el('option', null, ps.label); o.value = i; presetSel.appendChild(o); });
    const pl = el('label', 'fld'); pl.appendChild(el('span', null, 'Preset')); pl.appendChild(presetSel); s.appendChild(pl);
    const xi = num(s, 'X', () => c.start.x, v => (c.start.x = v), { unit: 'in', min: -72, max: 72 });
    const yi = num(s, 'Y', () => c.start.y, v => (c.start.y = v), { unit: 'in', min: -72, max: 72 });
    const hi = num(s, 'Heading', () => c.start.h, v => (c.start.h = v), { unit: '°', min: -360, max: 360 });
    presetSel.addEventListener('change', () => {
      const ps = START_PRESETS[presetSel.value]; if (!ps) return;
      Object.assign(c.start, { x: ps.x, y: ps.y, h: ps.h }); xi.value = ps.x; yi.value = ps.y; hi.value = ps.h; presetSel.value = '';
      this.cfgChanged();
    });
    s.appendChild(el('p', 'note', 'Field center is (0, 0). +X points to the blue wall, +Y points away from the audience (south) wall. Heading 0° faces +X; 90° faces +Y.'));
    const a = sec('Match');
    sel(a, 'Field elements', [['biobuzz', 'BIOBUZZ (hives, flowers, zones)'], ['empty', 'Empty field']], () => c.field || 'biobuzz', v => (c.field = v));
    num(a, 'Autonomous length', () => c.autoSeconds, v => (c.autoSeconds = Math.max(1, v)), { unit: 's', min: 1, max: 600 });
    chk(a, 'Stop autonomous when time runs out', () => c.enforceAutoTimer, v => (c.enforceAutoTimer = v));
    num(a, 'Wait between INIT and START', () => c.startDelay, v => (c.startDelay = Math.max(0, v)), { unit: 's (Run only)', min: 0, max: 30, step: 0.5 });
    const sh = sec('Shooter and intake (BIOBUZZ)');
    num(sh, 'Launch angle', () => c.launchDeg || 65, v => (c.launchDeg = Math.min(85, Math.max(10, v))), { unit: '° up from the floor', min: 10, max: 85 });
    num(sh, 'Top exit speed', () => c.exitSpeed || 420, v => (c.exitSpeed = Math.max(50, v)), { unit: 'in/s at full flywheel speed', min: 50, max: 1200 });
    num(sh, 'POLLEN pre-loaded', () => (c.preload == null ? 4 : c.preload), v => (c.preload = Math.max(0, Math.round(v))), { unit: 'in the robot at the start', min: 0, max: 8 });
    num(sh, 'Most POLLEN held', () => c.capacity || 4, v => (c.capacity = Math.max(1, Math.round(v))), { unit: 'at once', min: 1, max: 8 });
    sh.appendChild(el('p', 'note', 'Set each motor\'s Game job on the Hardware map tab. A ball launches when the shooter is above 30% speed and the feeder runs. With no feeder, the intake feeds the shooter. Exit speed scales with flywheel speed.'));
    const o = sec('Obstacles');
    const list = el('div', 'obs');
    const drawObs = () => {
      list.innerHTML = '';
      c.obstacles.forEach((ob, i) => {
        const r = el('div', 'obs-row');
        for (const k of ['x', 'y', 'w', 'd']) {
          const l = el('label', 'fld tiny'); l.appendChild(el('span', null, k.toUpperCase()));
          const inp = el('input'); inp.type = 'number'; inp.value = ob[k]; inp.id = `obs-${i}-${k}`;
          inp.addEventListener('change', () => { const v = parseFloat(inp.value); if (Number.isFinite(v)) { ob[k] = v; this.cfgChanged(); } });
          l.appendChild(inp); r.appendChild(l);
        }
        const del = el('button', 'icon-btn', '×'); del.type = 'button'; del.setAttribute('aria-label', 'Remove obstacle');
        del.addEventListener('click', () => { c.obstacles.splice(i, 1); drawObs(); this.cfgChanged(); });
        r.appendChild(del); list.appendChild(r);
      });
    };
    drawObs();
    o.appendChild(list);
    const add = el('button', 'btn small', 'Add an 18 × 18 in box'); add.type = 'button';
    add.addEventListener('click', () => { c.obstacles.push({ x: 0, y: 0, w: 18, d: 18, h: 6 }); drawObs(); this.cfgChanged(); });
    o.appendChild(add);
    o.appendChild(el('p', 'note', 'Boxes block the robot and the distance sensors. Sizes are in inches.'));
    const reset = el('button', 'btn small ghost', 'Reset robot settings'); reset.type = 'button';
    reset.addEventListener('click', () => { const keep = this.cfg.devices; this.cfg = FTC.defaultConfig(); this.cfg.devices = {}; for (const [n, dv] of Object.entries(keep)) FTC.ensureDevice(this.cfg, n, dv.type); this.buildRobotForm(); this.cfgChanged(); });
    f.appendChild(reset);
  },
  cfgChanged() {
    this.saveCfg();
    this.robotKey = null;
    this.rebuildRobot();
    this.scene.setStart(this.cfg);
    this.scene.setObstacles(this.cfg.obstacles);
    this.scene.setGame(this.cfg.field);
    if (this.sim) this.sim.drive = FTC.effectiveDrive(this.cfg, [...this.sim.devices.keys()]);
    $('#rerunHint').hidden = !(this.mode === 'replay');
  },

  /* ---------------- run control */
  updateButtons() {
    const op = this.currentOp();
    const auto = op && op.type === 'Autonomous';
    const live = this.mode === 'live';
    const sim = this.sim;
    $('#btnRun').hidden = !auto;
    $('#btnRun').disabled = !op || live;
    $('#btnInit').disabled = !op || live;
    $('#btnInit').classList.toggle('primary', !auto);
    $('#btnStart').disabled = !(live && sim && !sim.started && !sim.finished);
    $('#btnStop').disabled = !(live && sim && (this.match || !sim.finished));
    $('#btnStart').disabled = $('#btnStart').disabled || !!this.match;
    $('#btnPlace').hidden = live || this.cfg.field !== 'biobuzz' || !!this.placing;
    $('#btnPad').hidden = !(op && op.type === 'TeleOp');
    $('#opType').textContent = op ? (op.type === 'TeleOp' ? 'TeleOp' : 'Auto') : '—';
    $('#opType').className = 'pill ' + (op ? (op.type === 'TeleOp' ? 'pill-tele' : 'pill-auto') : '');
  },
  setState(label, cls) { const s = $('#state'); s.textContent = label; s.className = 'state ' + (cls || ''); },
  hardStop() {
    if (this.sim && !this.sim.finished) { this.sim.requestStop('Replaced by a new run'); this.sim.finishOpMode('Replaced by a new run'); }
    this.mode = 'idle';
    this.match = null;
    if (this.scene.onPlace) { this.scene.onPlace = null; $('#placeBar').hidden = true; this.placing = null; }
    $('#matchBanner').hidden = true;
    this.gp.show(false);
  },
  showIdleState() {
    this.sim = null;
    this.mode = 'idle';
    this.scene.setTrail(null);
    this.rebuildRobot();
    this.renderTelemetry(null);
    $('#log').innerHTML = '';
    $('#devs').innerHTML = '';
    this.devRowsFor = null;
    const op = this.currentOp();
    this.setState('READY');
    this.overlay(op ? (op.type === 'TeleOp' ? `Press INIT to start “${op.name}”. The gamepad opens when it initializes.` : `Press Run to simulate “${op.name}”.`) : 'Fix the error in the code to run it.');
    this.updateButtons();
  },
  overlay(text, busy) {
    const o = $('#overlay');
    if (!text && this.no3d) text = this.no3d;
    if (!text) { o.hidden = true; return; }
    o.hidden = false;
    o.querySelector('span').textContent = text;
    o.classList.toggle('busy', !!busy);
  },
  newSim() {
    const c = this.compileNow(true);
    if (!c) return null;
    const op = this.currentOp();
    if (!op) return null;
    this.hardStop();
    const sim = new FTC.Sim(this.cfg);
    this.sim = sim;
    this.devRowsFor = null; this.logCount = -1; this.lastMatch = null;
    this.rebuildRobot();
    return { sim, c, op };
  },
  runAuton(autoplay) {
    const r = this.newSim();
    if (!r) return;
    this.setState('SIMULATING', 'busy');
    this.overlay('Simulating…', true);
    this.mode = 'busy';
    this.updateButtons();
    setTimeout(() => {
      const { sim, c, op } = r;
      if (sim.load(c, op)) sim.runFast();
      this.robotKey = null; this.rebuildRobot();
      this.enterReplay(0, autoplay !== false);
      this.reportErrors();
    }, 30);
  },
  initLive() {
    const r = this.newSim();
    if (!r) return;
    const { sim, c, op } = r;
    sim.input = () => this.gp.input();
    if (!sim.load(c, op)) { this.enterReplay(0, false); this.reportErrors(); return; }
    this.mode = 'live';
    this.settle = 0;
    this.overlay(null);
    this.setState('INIT', 'init');
    if (op.type === 'TeleOp') this.gp.show(true);
    $('#rerunHint').hidden = true;
    this.scene.setTrail(null);
    this.updateButtons();
  },
  startLive() { if (this.sim && this.mode === 'live') { this.sim.start(); this.setState('RUNNING', 'run'); this.updateButtons(); } },
  stopLive() { if (this.match) { this.abortMatch(); return; } if (this.sim && this.mode === 'live') { this.sim.requestStop('STOP pressed'); this.setState('STOPPING', 'busy'); this.updateButtons(); } },
  enterReplay(t, play) {
    const sim = this.sim;
    this.mode = 'replay';
    this.overlay(null);
    this.end = sim.frames.length ? sim.frames[sim.frames.length - 1].f[0] : 0;
    this.cursor = Math.min(t, this.end);
    this.playing = !!play;
    const pts = [];
    for (let i = 0; i < sim.frames.length; i += 2) { const f = sim.frames[i].f; pts.push([f[1], f[2]]); }
    this.scene.setTrail(pts);
    const tl = $('#scrub');
    tl.max = this.end; tl.value = this.cursor;
    this.drawMarkers();
    this.setState(sim.errors.length ? 'ERROR' : 'REPLAY', sim.errors.length ? 'err' : 'replay');
    this.gp.show(false);
    this.updateButtons();
    $('#rerunHint').hidden = true;
  },
  reportErrors() {
    const e = this.sim && this.sim.errors[0];
    if (!e) return;
    this.setError({ title: `${e.type.split('.').pop()} at ${e.t.toFixed(2)} s`, message: e.message || '(no message)', line: e.line, hint: e.where ? `Happened ${e.where}.` : null });
    this.showTab('code');
  },

  /* ---------------- playback */
  frameAt(t) {
    const fr = this.sim.frames;
    if (!fr.length) return null;
    let lo = 0, hi = fr.length - 1;
    if (t <= fr[0].f[0]) hi = 0;
    else if (t >= fr[hi].f[0]) lo = hi;
    else {
      while (hi - lo > 1) { const m = (lo + hi) >> 1; if (fr[m].f[0] <= t) lo = m; else hi = m; }
    }
    const a = fr[lo].f, b = fr[hi].f;
    const k = hi === lo ? 0 : (t - a[0]) / (b[0] - a[0] || 1);
    const L = (i, def = 0) => { const va = a[i] ?? def, vb = b[i] ?? va; return va + (vb - va) * k; };
    const dev = new Map();
    this.sim.devOrder.forEach((n, i) => { const j = 4 + i * 3; if (a.length > j || b.length > j) dev.set(n, [L(j), L(j + 1), L(j + 2)]); });
    return { t, x: L(1), y: L(2), h: L(3), dev };
  },
  frame(now) {
    const dt = Math.min(0.1, (now - (this.lastWall || now)) / 1000);
    this.lastWall = now;
    const sim = this.sim;
    let state = null;
    if (sim && this.mode === 'live') {
      sim.advanceRealtime(dt);
      if (sim.started && !sim.finished && $('#state').textContent === 'INIT') this.setState('RUNNING', 'run');
      if (this.match) this.matchTick(dt);
      else if (sim.finished) {
        this.settle += dt;
        if (this.settle > 0.6) { this.enterReplay(sim.t, false); this.reportErrors(); }
      }
      state = this.frameAt(sim.t);
      this.cursor = sim.t;
      this.trailTick += dt;
      if (this.trailTick > 0.25) {
        this.trailTick = 0;
        const pts = [];
        const fr = sim.frames;
        const step = Math.max(1, Math.floor(fr.length / 3000));
        for (let i = 0; i < fr.length; i += step) pts.push([fr[i].f[1], fr[i].f[2]]);
        this.scene.setTrail(pts);
      }
    } else if (sim && this.mode === 'replay') {
      if (this.playing) {
        this.cursor += dt * this.speed;
        if (this.cursor >= this.end) { this.cursor = this.end; this.playing = false; }
      }
      state = this.frameAt(this.cursor);
    }
    try {
      if (state) this.scene.update(state, sim);
      this.scene.updateGame(this.gameSnapAt(state), state || this.idlePose());
      this.scene.render();
    } catch (e) {
      if (!this.drawErr) { this.drawErr = true; console.error(e); this.no3d = 'The 3D view hit a drawing error and stopped updating. Telemetry, devices and the console still work.'; this.overlay(null); }
    }
    this.panelTick += dt;
    if (this.panelTick > 0.08) { this.panelTick = 0; this.updatePanels(state); }
    if (this.gp.visible) this.gp.paint(sim && (this.gp.active === 1 ? sim.gamepad1 : sim.gamepad2));
    requestAnimationFrame(t => this.frame(t));
  },
  updatePanels(state) {
    const sim = this.sim;
    const t = this.cursor;
    // timeline
    const tl = $('#scrub');
    if (this.mode === 'live') { tl.max = Math.max(1, sim.t); tl.value = sim.t; }
    else if (this.mode === 'replay' && !this.scrubbing) tl.value = t;
    $('#tlTime').textContent = sim ? `${t.toFixed(2)} s` : '0.00 s';
    $('#btnPlay').textContent = this.playing ? '❚❚' : '▶';
    $('#btnPlay').setAttribute('aria-label', this.playing ? 'Pause' : 'Play');
    $('#btnPlay').disabled = this.mode !== 'replay';
    $('#liveTag').hidden = this.mode !== 'live';
    // clock
    const op = this.currentOp();
    let clock = '–:––', phase = '';
    if (sim && sim.opInfo) {
      if (sim.startT == null || t < sim.startT) { phase = 'INIT'; clock = fmtT(t); }
      else if (sim.opInfo.type === 'Autonomous') { phase = 'AUTO'; clock = fmtT(Math.max(0, this.cfg.autoSeconds - (t - sim.startT))); }
      else { phase = 'TELEOP'; clock = fmtT(t - sim.startT); }
      if (sim.endT != null && t >= sim.endT) phase = 'ENDED';
    } else if (op) { phase = op.type === 'TeleOp' ? 'TELEOP' : 'AUTO'; clock = op.type === 'TeleOp' ? '0:00' : fmtT(this.cfg.autoSeconds); }
    if (this.match) { const mc = this.matchClock(); clock = mc.clock; phase = mc.phase; }
    $('#clock').textContent = clock;
    $('#phase').textContent = phase;
    this.renderScore();
    // HUD
    if (state) {
      const sp = sim && this.mode === 'live' ? Math.hypot(sim.robot.vx, sim.robot.vy) : this.speedAt(t);
      const hdeg = ((state.h * 180 / Math.PI) % 360 + 540) % 360 - 180;
      $('#hudX').textContent = state.x.toFixed(1);
      $('#hudY').textContent = state.y.toFixed(1);
      $('#hudH').textContent = hdeg.toFixed(1);
      $('#hudV').textContent = sp.toFixed(1);
    } else {
      $('#hudX').textContent = this.cfg.start.x.toFixed(1); $('#hudY').textContent = this.cfg.start.y.toFixed(1);
      $('#hudH').textContent = Number(this.cfg.start.h).toFixed(1); $('#hudV').textContent = '0.0';
    }
    if (!sim) return;
    this.renderTelemetry(this.teleAt(t));
    this.renderDevices(state);
    this.renderLog(t);
  },
  speedAt(t) {
    const a = this.frameAt(Math.max(0, t - 0.05)), b = this.frameAt(t + 0.05);
    if (!a || !b || b.t === a.t) return 0;
    return Math.hypot(b.x - a.x, b.y - a.y) / (b.t - a.t || 0.1);
  },
  teleAt(t) {
    const tl = this.sim.tele;
    if (!tl.length || tl[0].t > t) return null;
    let lo = 0, hi = tl.length - 1;
    while (lo < hi) { const m = (lo + hi + 1) >> 1; if (tl[m].t <= t) lo = m; else hi = m - 1; }
    return tl[lo].lines;
  },
  renderTelemetry(lines) {
    const host = $('#tele');
    const key = JSON.stringify(lines);
    if (key === this.teleKey) return;
    this.teleKey = key;
    host.innerHTML = '';
    if (!lines || !lines.length) { host.appendChild(el('div', 'tele-empty', 'No telemetry yet. telemetry.update() sends lines here.')); return; }
    for (const [cap, val] of lines) {
      const row = el('div', 'tele-row');
      if (val === null) row.appendChild(el('span', 'tele-line', cap));
      else { row.appendChild(el('span', 'tele-cap', cap)); row.appendChild(el('span', 'tele-sep', ':')); row.appendChild(el('span', 'tele-val', val)); }
      host.appendChild(row);
    }
  },
  renderDevices(state) {
    const sim = this.sim;
    const host = $('#devs');
    const names = [...sim.devices.keys()];
    const key = names.join('|');
    if (this.devRowsFor !== key) {
      this.devRowsFor = key;
      host.innerHTML = '';
      this.devRows = new Map();
      if (!names.length) host.appendChild(el('p', 'empty', 'No devices mapped yet.'));
      for (const n of names) {
        const dev = sim.devices.get(n);
        const kind = dev.constructor.$kind;
        const row = el('div', 'dev ' + kind);
        const top = el('div', 'dev-top');
        top.appendChild(el('code', null, n));
        const d = this.cfg.devices[n] || {};
        let tag = kind === 'motor' ? (['FL', 'FR', 'BL', 'BR', 'L', 'R'].includes(d.role) ? d.role : 'motor') : kind === 'sensor' ? (d.sensorKind || 'sensor') : kind;
        top.appendChild(el('span', 'dev-tag', tag));
        const mode = el('span', 'dev-mode', '');
        top.appendChild(mode);
        const val = el('span', 'dev-val', '');
        top.appendChild(val);
        row.appendChild(top);
        let bar = null;
        if (kind === 'motor' || kind === 'crservo' || kind === 'servo') {
          bar = el('div', 'pbar' + (kind === 'servo' ? ' unipolar' : ''));
          bar.appendChild(el('i'));
          row.appendChild(bar);
        }
        host.appendChild(row);
        this.devRows.set(n, { val, bar, kind, dev, mode });
      }
    }
    for (const [n, r] of this.devRows) {
      const st = state && state.dev.get(n);
      const setBar = (v, uni) => {
        if (!r.bar) return;
        const i = r.bar.firstElementChild;
        if (uni) { i.style.left = '0'; i.style.width = (Math.max(0, Math.min(1, v)) * 100) + '%'; }
        else { const w = Math.min(1, Math.abs(v)) * 50; i.style.left = (v >= 0 ? 50 : 50 - w) + '%'; i.style.width = w + '%'; }
        r.bar.classList.toggle('neg', v < 0);
      };
      if (r.kind === 'motor') {
        const live = this.mode === 'live';
        const p = st ? st[2] : 0;
        r.val.textContent = `${st ? Math.round(st[1]) : 0} · ${p >= 0 ? ' ' : ''}${p.toFixed(2)}`;
        const mn = r.dev.mode.$name;
        r.mode.textContent = live ? ({ RUN_TO_POSITION: 'RTP', RUN_USING_ENCODER: 'ENC', RUN_WITHOUT_ENCODER: '', STOP_AND_RESET_ENCODER: 'RESET' }[mn] ?? '') : '';
        r.mode.title = mn;
        setBar(p);
      } else if (r.kind === 'servo') {
        const act = st ? st[0] : 0.5, on = st && st[1], cmd = st ? st[2] : -1;
        r.val.textContent = on ? `${cmd.toFixed(2)} → at ${act.toFixed(2)}` : 'not set yet';
        setBar(on ? act : 0, true);
      } else if (r.kind === 'crservo') {
        const p = st ? st[2] : 0; r.val.textContent = `power ${p.toFixed(2)}`; setBar(p);
      } else if (r.kind === 'imu') {
        const yaw = state ? ((((state.h - sim.startPose.h - (r.dev.yawOffset || 0)) * 180 / Math.PI) % 360) + 540) % 360 - 180 : 0;
        r.val.textContent = `yaw ${yaw.toFixed(1)}°`;
      } else if (r.kind === 'sensor' && state) {
        const d = this.cfg.devices[n] || {};
        if (d.sensorKind === 'distance' || d.sensorKind === 'touch') {
          const saved = sim.robot; sim.robot = { x: state.x, y: state.y, h: state.h };
          const dist = sim.raycast({ mount: d.mount || 'front' });
          sim.robot = saved;
          r.val.textContent = d.sensorKind === 'touch' ? (dist < 0.6 ? 'pressed' : 'released') : (dist > 78.74 ? 'out of range' : `${dist.toFixed(1)} in`);
        } else r.val.textContent = 'floor';
      } else if (r.kind === 'odometry' && state) {
        const dx = state.x - sim.startPose.x, dy = state.y - sim.startPose.y, c = Math.cos(-sim.startPose.h), s = Math.sin(-sim.startPose.h);
        r.val.textContent = `${(dx * c - dy * s).toFixed(1)}, ${(dx * s + dy * c).toFixed(1)} in`;
      }
    }
  },
  renderLog(t) {
    const sim = this.sim;
    const showEv = $('#showEvents').checked;
    const logs = sim.logs.filter(l => showEv || l.level !== 'event' || l.kind === 'start' || l.kind === 'end' || l.kind === 'bump');
    let upto = 0;
    while (upto < logs.length && logs[upto].t <= t + 1e-6) upto++;
    const key = logs.length + ':' + upto + ':' + showEv;
    if (key === this.logCursorKey) return;
    this.logCursorKey = key;
    const host = $('#log');
    const atBottom = host.scrollHeight - host.scrollTop - host.clientHeight < 30;
    host.innerHTML = '';
    if (!logs.length) { host.appendChild(el('div', 'empty', 'Errors, warnings, System.out.println and RobotLog output appear here.')); return; }
    const from = Math.max(0, logs.length - 400);
    for (let i = from; i < logs.length; i++) {
      const l = logs[i];
      const row = el('div', 'log-row lv-' + l.level + (l.kind ? ' ev-' + l.kind : '') + (i >= upto ? ' future' : ''));
      const tb = el('button', 'log-t', l.t.toFixed(2)); tb.type = 'button';
      tb.title = 'Jump to this moment';
      tb.addEventListener('click', () => { if (this.mode === 'replay') { this.cursor = l.t; this.playing = false; } });
      row.appendChild(tb);
      row.appendChild(el('span', 'log-msg', l.msg));
      const m = /line (\d+)/.exec(l.msg);
      if (m && l.level === 'error') { const b = el('button', 'linkbtn', 'show'); b.type = 'button'; b.addEventListener('click', () => this.gotoLine(Number(m[1]))); row.appendChild(b); }
      host.appendChild(row);
    }
    if (atBottom || this.mode === 'live') host.scrollTop = host.scrollHeight;
  },
  drawMarkers() {
    const cv = $('#markers');
    const w = cv.clientWidth, h = cv.clientHeight;
    if (!w) return;
    const dpr = G.devicePixelRatio || 1;
    cv.width = w * dpr; cv.height = h * dpr;
    const g = cv.getContext('2d');
    g.scale(dpr, dpr);
    g.clearRect(0, 0, w, h);
    if (!this.sim || !this.end) return;
    const cs = getComputedStyle(document.documentElement);
    const col = { start: cs.getPropertyValue('--ok').trim(), end: cs.getPropertyValue('--muted').trim(), stop: cs.getPropertyValue('--muted').trim(), bump: cs.getPropertyValue('--warn').trim(), error: cs.getPropertyValue('--err').trim(), warn: cs.getPropertyValue('--warn').trim() };
    for (const l of this.sim.logs) {
      const c = l.level === 'error' ? col.error : l.level === 'warn' ? col.warn : col[l.kind];
      if (!c) continue;
      const x = Math.round(l.t / this.end * (w - 2)) + 1;
      g.fillStyle = c;
      g.fillRect(x - 1, 0, 2, h);
    }
  },

  /* ---------------- misc bindings */
  showTab(name) {
    document.querySelectorAll('.tabs [data-tab]').forEach(b => { const on = b.dataset.tab === name; b.classList.toggle('on', on); b.setAttribute('aria-selected', on); });
    document.querySelectorAll('.tab').forEach(s => (s.hidden = s.id !== 'tab-' + name));
    if (name === 'code') setTimeout(() => this.placeErrLine(), 0);
  },
  bindControls() {
    document.querySelectorAll('.tabs [data-tab]').forEach(b => b.addEventListener('click', () => this.showTab(b.dataset.tab)));
    $('#btnRun').addEventListener('click', () => this.runAuton(true));
    $('#btnInit').addEventListener('click', () => this.initLive());
    $('#btnStart').addEventListener('click', () => this.startLive());
    $('#btnStop').addEventListener('click', () => this.stopLive());
    $('#btnPad').addEventListener('click', () => this.gp.show(!this.gp.visible));
    $('#btnCheck').addEventListener('click', () => { this.compileNow(true); this.rebuildRobot(); });
    $('#opmode').addEventListener('change', e => { this.opIdx = Number(e.target.value); this.hardStop(); this.showIdleState(); });
    $('#btnPlay').addEventListener('click', () => {
      if (this.mode !== 'replay') return;
      if (!this.playing && this.cursor >= this.end - 1e-6) this.cursor = 0;
      this.playing = !this.playing;
    });
    $('#btnRestart').addEventListener('click', () => { if (this.mode === 'replay') { this.cursor = 0; this.playing = true; } });
    const sc = $('#scrub');
    sc.addEventListener('input', () => { if (this.mode !== 'replay') return; this.scrubbing = true; this.cursor = parseFloat(sc.value); this.playing = false; });
    sc.addEventListener('change', () => { this.scrubbing = false; });
    $('#speed').addEventListener('change', e => { this.speed = parseFloat(e.target.value); });
    $('#showEvents').addEventListener('change', () => { this.logCursorKey = ''; });
    document.querySelectorAll('[data-cam]').forEach(b => b.addEventListener('click', () => {
      document.querySelectorAll('[data-cam]').forEach(x => x.classList.toggle('on', x === b));
      this.scene.setCameraMode(b.dataset.cam);
    }));
    $('#rerunBtn').addEventListener('click', () => this.runAuton(true));
    G.addEventListener('resize', () => { this.drawMarkers(); this.placeErrLine(); });
    G.addEventListener('keydown', e => {
      const t = e.target;
      if (t && (t.tagName === 'TEXTAREA' || t.tagName === 'INPUT' || t.tagName === 'SELECT')) return;
      if (e.code === 'Space' && this.mode === 'replay' && !this.gp.visible) { e.preventDefault(); $('#btnPlay').click(); }
    });
  },
  watchTheme() {
    const re = () => { this.scene.applyTheme(); this.drawMarkers(); };
    try { G.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', re); } catch (e) { /* old browsers */ }
    try { new MutationObserver(re).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] }); } catch (e) { /* ignore */ }
  },
};
FTC.App = App;
G.addEventListener('DOMContentLoaded', () => {
  if (!G.THREE) { document.getElementById('overlay').hidden = false; document.querySelector('#overlay span').textContent = 'The 3D library did not load. Check your connection and reload the page.'; return; }
  try { App.init(); } catch (e) { console.error(e); const o = document.getElementById('overlay'); o.hidden = false; o.querySelector('span').textContent = 'Something went wrong starting the simulator: ' + e.message; }
});
})(typeof globalThis !== 'undefined' ? globalThis : window);
