/* Full BIOBUZZ match mode, robot placement, scoreboard and the physical-controller dialog.
   Extends FTC.App (ui/app.js). */
(function (G) {
'use strict';
const FTC = G.FTC;
const $ = s => document.querySelector(s);
const el = (tag, cls, txt) => { const e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; };
const store = {
  get(k) { try { return G.localStorage.getItem('ftcsim.' + k); } catch (e) { return null; } },
  set(k, v) { try { G.localStorage.setItem('ftcsim.' + k, v); } catch (e) { /* storage blocked */ } },
};
const fmtT = t => Math.floor(Math.max(0, t) / 60) + ':' + String(Math.floor(Math.max(0, t) % 60)).padStart(2, '0');
const AUTO_S = 30, TRANSITION_S = 8, TELEOP_S = 120;
const WALL = 70.5;

Object.assign(FTC.App, {
  /* ---------------- setup */
  initMatchUI() {
    this.playMode = 'practice';
    $('#btnMode').addEventListener('click', () => this.openModal('#modeModal'));
    document.querySelectorAll('#modeModal [data-mode]').forEach(b => b.addEventListener('click', () => {
      this.closeModal('#modeModal');
      if (b.dataset.mode === 'match') this.openMatchSetup();
      else this.setPlayMode('practice');
    }));
    document.querySelectorAll('.modal [data-close]').forEach(b => b.addEventListener('click', () => this.closeModal('#' + b.closest('.modal').id)));
    $('#btnMatchNext').addEventListener('click', () => this.matchSetupNext());
    document.querySelectorAll('#setupModal [data-alliance]').forEach(b => b.addEventListener('click', () => this.setSetupAlliance(b.dataset.alliance)));
    for (const k of ['autoRed', 'autoBlue', 'teleop']) {
      const ta = $('#code-' + k);
      let timer = null;
      ta.addEventListener('input', () => { store.set('match.' + k, ta.value); clearTimeout(timer); timer = setTimeout(() => this.checkMatchCode(k), 500); });
      ta.addEventListener('keydown', e => { if (e.key === 'Tab' && !e.shiftKey) { e.preventDefault(); ta.setRangeText('    ', ta.selectionStart, ta.selectionEnd, 'end'); } });
    }
    document.querySelectorAll('#setupModal [data-fill]').forEach(b => b.addEventListener('click', () => {
      const k = b.dataset.fill, ta = $('#code-' + k);
      ta.value = $('#code').value; store.set('match.' + k, ta.value); this.checkMatchCode(k);
    }));
    // placement
    $('#btnPlace').addEventListener('click', () => this.startPlacing('practice'));
    $('#placeRotate').addEventListener('click', () => { this.cfg.start.h = (((this.cfg.start.h + 90) % 360) + 360) % 360; this.placeAt({ x: this.cfg.start.x, y: this.cfg.start.y }); });
    document.querySelectorAll('#placeBar [data-alliance]').forEach(b => b.addEventListener('click', () => { this.placeAlliance = b.dataset.alliance; this.cfg.start.h = b.dataset.alliance === 'red' ? 0 : 180; this.placeAt({ x: this.cfg.start.x, y: this.cfg.start.y }); this.paintPlaceBar(); }));
    $('#placeDone').addEventListener('click', () => this.finishPlacing());
    // controller dialog
    $('#btnController').addEventListener('click', () => this.openPadDialog());
    this.gp.onChange(() => { this.paintPadButton(); if (!$('#padModal').hidden) this.paintPadDialog(); });
    this.paintPadButton();
    $('#resultAgain').addEventListener('click', () => { this.closeModal('#resultModal'); this.openMatchSetup(); });
    $('#resultPractice').addEventListener('click', () => { this.closeModal('#resultModal'); this.setPlayMode('practice'); });
    this.cfg.alliance = this.cfg.alliance || (this.cfg.start.x > 0 ? 'blue' : 'red');
    this.openModal('#modeModal');
  },
  openModal(sel) { const m = $(sel); m.hidden = false; const f = m.querySelector('button, textarea, select'); if (f) setTimeout(() => f.focus(), 30); },
  closeModal(sel) { $(sel).hidden = true; if (sel === '#padModal') clearInterval(this.padPoll); },
  setPlayMode(mode) {
    this.playMode = mode;
    $('#btnMode').textContent = mode === 'match' ? 'Full match' : 'Practice';
    $('#btnMode').classList.toggle('on', mode === 'match');
    document.body.classList.toggle('in-match', mode === 'match');
    this.updateButtons();
  },

  /* ---------------- full match setup */
  openMatchSetup() {
    const exA = FTC.EXAMPLES.find(e => e.id === 'encoder-auto').code;
    const exT = FTC.EXAMPLES.find(e => e.id === 'field-centric').code;
    const cur = $('#code').value;
    const curIsTele = /@TeleOp/.test(cur);
    $('#code-autoRed').value = store.get('match.autoRed') || (curIsTele ? exA : cur);
    $('#code-autoBlue').value = store.get('match.autoBlue') || (curIsTele ? exA : cur);
    $('#code-teleop').value = store.get('match.teleop') || (curIsTele ? cur : exT);
    this.setSetupAlliance(store.get('match.alliance') || this.cfg.alliance || 'red');
    for (const k of ['autoRed', 'autoBlue', 'teleop']) this.checkMatchCode(k);
    this.openModal('#setupModal');
  },
  setSetupAlliance(a) {
    this.setupAlliance = a;
    store.set('match.alliance', a);
    document.querySelectorAll('#setupModal [data-alliance]').forEach(b => { const on = b.dataset.alliance === a; b.classList.toggle('on', on); b.setAttribute('aria-pressed', on); });
    $('#setupAllianceNote').textContent = `Your robot runs the ${a === 'red' ? 'RED' : 'BLUE'} auton, then the TeleOp. It starts against the ${a} alliance wall.`;
  },
  compileFor(code, wantType) {
    const c = FTC.compileJava(code);
    if (!c.opModes.length) throw Object.assign(new Error('No OpMode found. The class must extend LinearOpMode or OpMode.'), { line: 1 });
    const op = c.opModes.find(o => o.type === wantType && !o.disabled) || c.opModes.find(o => !o.disabled) || c.opModes[0];
    return { c, op };
  },
  checkMatchCode(k) {
    const msg = $('#msg-' + k);
    const want = k === 'teleop' ? 'TeleOp' : 'Autonomous';
    try {
      const { op } = this.compileFor($('#code-' + k).value, want);
      msg.className = 'msg ok';
      msg.textContent = `Ready: “${op.name}”${op.type !== want ? ` (marked @${op.type === 'TeleOp' ? 'TeleOp' : 'Autonomous'}, will still run)` : ''}`;
      return true;
    } catch (e) {
      msg.className = 'msg bad';
      msg.textContent = `${e.name === 'JavaSyntaxError' ? 'Syntax error' : 'Error'}${e.line ? ' on line ' + e.line : ''}: ${e.message}`;
      return false;
    }
  },
  matchSetupNext() {
    const a = this.setupAlliance;
    const autoKey = a === 'red' ? 'autoRed' : 'autoBlue';
    const ok = this.checkMatchCode(autoKey) && this.checkMatchCode('teleop');
    if (!ok) { $('#setupError').hidden = false; $('#setupError').textContent = `Fix the ${!this.checkMatchCode(autoKey) ? (a === 'red' ? 'red auton' : 'blue auton') : 'TeleOp'} code first. The message under it says what is wrong.`; return; }
    $('#setupError').hidden = true;
    const auto = this.compileFor($('#code-' + autoKey).value, 'Autonomous');
    const tele = this.compileFor($('#code-teleop').value, 'TeleOp');
    // device names from both programs, so the Hardware map and the robot model know about them
    for (const code of [$('#code-' + autoKey).value, $('#code-teleop').value]) for (const d of FTC.prescanDevices(code)) FTC.ensureDevice(this.cfg, d.name, d.type);
    this.pendingMatch = { alliance: a, auto, tele, autoCode: $('#code-' + autoKey).value, teleCode: $('#code-teleop').value };
    this.closeModal('#setupModal');
    this.setPlayMode('match');
    this.cfg.alliance = a;
    this.robotKey = null;
    this.matchCodeNames = new Set([...FTC.prescanDevices(this.pendingMatch.autoCode), ...FTC.prescanDevices(this.pendingMatch.teleCode)].map(d => d.name));
    this.startPlacing('match');
  },

  /* ---------------- placement on the alliance wall */
  startPlacing(kind) {
    this.hardStop();
    this.sim = null;
    this.mode = 'idle';
    this.placing = kind;
    this.placeAlliance = kind === 'match' ? this.pendingMatch.alliance : (this.cfg.alliance || 'red');
    const wantH = this.placeAlliance === 'red' ? 0 : 180;
    if (!this.onAllianceWall(this.placeAlliance)) this.cfg.start.h = wantH;
    this.scene.setTrail(null);
    this.scene.setCameraMode('top');
    document.querySelectorAll('[data-cam]').forEach(x => x.classList.toggle('on', x.dataset.cam === 'top'));
    this.scene.onPlace = p => this.placeAt(p);
    this.placeAt({ x: this.cfg.start.x, y: this.cfg.start.y });
    $('#placeBar').hidden = false;
    $('#placeDone').textContent = kind === 'match' ? 'Start match' : 'Done';
    $('#placeDone').classList.toggle('go', kind === 'match');
    this.paintPlaceBar();
    this.overlay(null);
    this.renderTelemetry(null);
    $('#log').innerHTML = '';
    $('#devs').innerHTML = '';
    this.devRowsFor = null;
    this.setState(kind === 'match' ? 'PLACE' : 'READY', 'init');
    this.updateButtons();
  },
  paintPlaceBar() {
    const a = this.placeAlliance;
    document.querySelectorAll('#placeBar [data-alliance]').forEach(b => b.classList.toggle('on', b.dataset.alliance === a));
    $('#placeAllianceSel').hidden = this.placing === 'match';
    $('#placeText').textContent = `Drag on the field to slide the robot along the ${a === 'red' ? 'RED' : 'BLUE'} alliance wall.`;
  },
  onAllianceWall(a) {
    const { ex } = this.extents(this.cfg.start.h);
    return Math.abs(Math.abs(this.cfg.start.x) - (WALL - ex)) < 0.6 && Math.sign(this.cfg.start.x) === (a === 'red' ? -1 : 1);
  },
  extents(hDeg) {
    const h = hDeg * Math.PI / 180, L = this.cfg.robotLength / 2, W = this.cfg.robotWidth / 2;
    return { ex: Math.abs(Math.cos(h)) * L + Math.abs(Math.sin(h)) * W, ey: Math.abs(Math.sin(h)) * L + Math.abs(Math.cos(h)) * W };
  },
  placeAt(p) {
    const a = this.placeAlliance || 'red';
    const { ex, ey } = this.extents(this.cfg.start.h);
    const x = a === 'red' ? -WALL + ex : WALL - ex;
    const y = Math.max(-WALL + ey, Math.min(WALL - ey, p.y));
    this.cfg.start.x = Math.round(x * 10) / 10;
    this.cfg.start.y = Math.round(y * 10) / 10;
    this.scene.setStart(this.cfg);
    this.scene.update(this.idlePose(), null);
    this.previewKey = null;
  },
  finishPlacing() {
    this.scene.onPlace = null;
    $('#placeBar').hidden = true;
    this.cfg.alliance = this.placeAlliance;
    this.saveCfg();
    const kind = this.placing;
    this.placing = null;
    this.buildRobotForm();
    this.scene.setCameraMode('orbit');
    document.querySelectorAll('[data-cam]').forEach(x => x.classList.toggle('on', x.dataset.cam === 'orbit'));
    if (kind === 'match') this.startMatch();
    else this.showIdleState();
  },
  idlePose() { return { x: this.cfg.start.x, y: this.cfg.start.y, h: this.cfg.start.h * Math.PI / 180, dev: new Map() }; },

  /* ---------------- the match */
  startMatch() {
    const pm = this.pendingMatch;
    if (!pm) return;
    this.hardStop();
    const cfg = Object.assign({}, this.cfg, { autoSeconds: AUTO_S, enforceAutoTimer: true });
    const sim = new FTC.Sim(cfg);
    this.sim = sim;
    this.devRowsFor = null; this.logCount = -1; this.logCursorKey = '';
    this.rebuildRobot();
    sim.input = null;
    sim.load(pm.auto.c, pm.auto.op);
    sim.start();
    const start = { x: cfg.start.x, y: cfg.start.y };
    this.match = { phase: 'auto', t0: sim.t, alliance: pm.alliance, start, said: {} };
    this.mode = 'live';
    this.settle = 0;
    this.overlay(null);
    this.gp.show(false);
    this.scene.setTrail(null);
    this.setState('AUTO', 'run');
    this.banner('AUTO', `${pm.alliance === 'red' ? 'Red' : 'Blue'} alliance: ${pm.auto.op.name}`, 1800);
    this.updateButtons();
  },
  matchTick() {
    const m = this.match, sim = this.sim, t = sim.t;
    if (m.phase === 'auto') {
      if (t - m.t0 >= AUTO_S) {
        if (!sim.stopRequested) sim.requestStop('Autonomous period ended (30 s)');
        sim.finishOpMode('Autonomous period ended (30 s)');
        if (sim.game) {
          const left = sim.game.checkLeave(m.alliance, m.start), parked = sim.game.checkPark(m.alliance);
          sim.event('game', `AUTO over: LEAVE ${left ? '+3' : 'not earned'}, PARK ${parked ? '+5' : 'not earned'}`);
        }
        m.phase = 'transition'; m.tT = t;
        this.setState('TRANSITION', 'init');
      }
    } else if (m.phase === 'transition') {
      const e = t - m.tT;
      if (e < TRANSITION_S - 3) { if (!m.said.pick) { m.said.pick = 1; this.banner('Drivers, pick up your controllers', 'TeleOp starts in a few seconds', 0); } }
      else {
        const n = Math.ceil(TRANSITION_S - e);
        if (n >= 1 && m.said.n !== n) { m.said.n = n; this.banner(String(n), '', 0); }
      }
      if (e >= TRANSITION_S) {
        const pm = this.pendingMatch;
        sim.switchProgram(pm.tele.c, pm.tele.op);
        sim.input = () => this.gp.input();
        sim.start();
        m.phase = 'teleop'; m.tTele = t;
        this.gp.show(true);
        this.devRowsFor = null;
        this.setState('TELEOP', 'run');
        this.banner('TELEOP', pm.tele.op.name, 1400);
      }
    } else if (m.phase === 'teleop') {
      const left = TELEOP_S - (t - m.tTele);
      if (left <= 60 && !m.said.endgame) { m.said.endgame = 1; this.banner('Final minute', 'FLOWER scoring is open', 1600); }
      if (left <= 0) {
        if (sim.game) { const parked = sim.game.checkPark(m.alliance); sim.event('game', `Match over: PARK ${parked ? '+5' : 'not earned'}`); }
        sim.requestStop('Match over');
        sim.finishOpMode('Match over');
        m.phase = 'over'; m.tOver = t;
        this.gp.show(false);
        this.setState('MATCH OVER', 'replay');
        this.banner('Match over', '', 2200);
      }
    } else if (m.phase === 'over') {
      if (t - m.tOver > 2.2) {
        const final = sim.game ? sim.game.score() : null;
        this.lastMatch = { alliance: m.alliance, final };
        this.match = null;
        this.enterReplay(sim.t, false);
        this.reportErrors();
        this.showResults();
      }
    }
  },
  abortMatch() {
    if (!this.match) return;
    const m = this.match;
    m.phase = 'over'; m.tOver = this.sim.t - 2;
    this.sim.requestStop('Match stopped');
    this.sim.finishOpMode('Match stopped');
    this.gp.show(false);
  },
  matchClock() {
    const m = this.match, t = this.sim ? this.sim.t : 0;
    if (m.phase === 'auto') return { phase: 'AUTO', clock: fmtT(AUTO_S - (t - m.t0)) };
    if (m.phase === 'transition') return { phase: 'GET READY', clock: fmtT(TRANSITION_S - (t - m.tT)) };
    if (m.phase === 'teleop') return { phase: 'TELEOP', clock: fmtT(TELEOP_S - (t - m.tTele)) };
    return { phase: 'MATCH OVER', clock: '0:00' };
  },
  banner(big, small, ms) {
    const b = $('#matchBanner');
    b.querySelector('b').textContent = big;
    b.querySelector('span').textContent = small || '';
    b.hidden = false;
    b.classList.remove('pop'); void b.offsetWidth; b.classList.add('pop');
    clearTimeout(this.bannerTimer);
    if (ms) this.bannerTimer = setTimeout(() => { b.hidden = true; }, ms);
    else this.bannerTimer = setTimeout(() => { b.hidden = true; }, 1100);
  },
  showResults() {
    const r = this.lastMatch;
    if (!r || !r.final) return;
    const us = r.final[r.alliance];
    const rows = [['HIVE tips', us.parts.tips, `${us.tipCount} × 20`], ['POLLEN in up CELLS', us.parts.cells, `${us.inUp} × 2`], ['GARDEN', us.parts.garden, `${us.parts.garden} × 1`], ['LEAVE', us.parts.leave, ''], ['PARK', us.parts.park, '']];
    const host = $('#resultBody');
    host.innerHTML = '';
    const head = el('div', 'res-head');
    const mk = (al, total) => { const d = el('div', 'res-team ' + al); d.appendChild(el('small', null, al === 'red' ? 'RED' : 'BLUE')); d.appendChild(el('b', null, String(total))); return d; };
    head.appendChild(mk('red', r.alliance === 'red' ? us.total : 0));
    head.appendChild(mk('blue', r.alliance === 'blue' ? us.total : 0));
    host.appendChild(head);
    const tbl = el('table', 'res-table');
    for (const [k, v, how] of rows) { const tr = el('tr'); tr.appendChild(el('td', null, k)); tr.appendChild(el('td', 'how', how)); tr.appendChild(el('td', 'pts', String(v))); tbl.appendChild(tr); }
    const tr = el('tr', 'total'); tr.appendChild(el('td', null, 'Total')); tr.appendChild(el('td')); tr.appendChild(el('td', 'pts', String(us.total))); tbl.appendChild(tr);
    host.appendChild(tbl);
    host.appendChild(el('p', 'note', 'The other alliance shows 0 for now. Drag the timeline to replay the match.'));
    this.openModal('#resultModal');
  },

  /* ---------------- game state for drawing and the scoreboard */
  previewSnap() {
    const key = JSON.stringify([this.cfg.preload, this.cfg.field]);
    if (!this.previewGame || this.previewKey !== key) {
      const fake = { cfg: this.cfg, devices: new Map(), robot: this.idlePose(), event() {}, corners: () => [] };
      this.previewGame = new FTC.Game(fake);
      this.previewKey = key;
    }
    return this.previewGame.snapshot();
  },
  gameSnapAt() {
    if (this.cfg.field !== 'biobuzz' || !FTC.Game) return null;
    const sim = this.sim;
    if (sim && sim.game) {
      if (this.mode === 'replay' && sim.gameFrames.length) {
        const fr = sim.gameFrames, t = this.cursor;
        let lo = 0, hi = fr.length - 1;
        while (lo < hi) { const m = (lo + hi + 1) >> 1; if (fr[m].t <= t) lo = m; else hi = m - 1; }
        return fr[lo];
      }
      return sim.game.snapshot();
    }
    return this.previewSnap();
  },
  renderScore() {
    const sb = $('#scoreboard');
    const snap = this.cfg.field === 'biobuzz' ? (this.sim && this.sim.game && this.mode !== 'replay' ? { score: this.sim.game.score() } : this.gameSnapAt()) : null;
    if (!snap || !snap.score) { sb.hidden = true; return; }
    sb.hidden = false;
    const al = (this.match && this.match.alliance) || (this.lastMatch && this.mode === 'replay' && this.lastMatch.alliance) || this.cfg.alliance || 'red';
    const us = snap.score[al];
    const key = JSON.stringify([al, us, snap.score.holding]);
    if (key === this.scoreKey) return;
    this.scoreKey = key;
    $('#sbRed').textContent = al === 'red' ? us.total : 0;
    $('#sbBlue').textContent = al === 'blue' ? us.total : 0;
    $('#sbTips').textContent = `${us.tipCount} tip${us.tipCount === 1 ? '' : 's'}`;
    $('#sbNext').textContent = `${us.toTip} to tip`;
    $('#sbHold').textContent = `holding ${snap.score.holding}`;
    sb.classList.toggle('us-red', al === 'red');
    sb.classList.toggle('us-blue', al === 'blue');
  },

  /* ---------------- physical controller */
  openPadDialog() {
    this.openModal('#padModal');
    this.paintPadDialog();
    clearInterval(this.padPoll);
    this.padPoll = setInterval(() => { this.gp.scanPhysical(); this.paintPadDialog(); this.paintPadButton(); }, 300);
  },
  paintPadButton() {
    const n = this.gp.connected().filter(g => g.index === this.gp.physMap[1] || g.index === this.gp.physMap[2]).length;
    const b = $('#btnController');
    b.classList.toggle('on', n > 0);
    b.querySelector('span').textContent = n ? `${n} controller${n > 1 ? 's' : ''}` : 'Connect controller';
  },
  paintPadDialog() {
    const st = this.gp.apiStatus();
    $('#padBlocked').hidden = st === 'ok';
    $('#padBlocked').textContent = st === 'blocked'
      ? 'This view of the page is not allowed to read controllers. Open the simulator directly (your GitHub Pages site, or the downloaded index.html) to use a physical controller.'
      : 'This browser cannot read game controllers. Try Chrome or Edge.';
    const list = $('#padList');
    const pads = this.gp.connected();
    const key = JSON.stringify([pads.map(p => [p.index, p.id, p.mapping]), this.gp.physMap]);
    if (key === this.padKey) { this.paintPadLive(pads); return; }
    this.padKey = key;
    list.innerHTML = '';
    if (!pads.length) { list.appendChild(el('p', 'empty', st === 'ok' ? 'Waiting for a controller. Press any button on it.' : '')); return; }
    for (const p of pads) {
      const row = el('div', 'pad-row');
      const name = el('div', 'pad-name');
      name.appendChild(el('b', null, p.id.replace(/\(.*?\)/g, '').trim() || 'Controller'));
      name.appendChild(el('small', null, p.mapping === 'standard' ? 'Standard layout' : 'Non-standard layout: some buttons may be swapped'));
      row.appendChild(name);
      const live = el('span', 'pad-live'); live.dataset.index = p.index;
      row.appendChild(live);
      const seg = el('div', 'seg');
      for (const u of [1, 2]) {
        const b = el('button', this.gp.physMap[u] === p.index ? 'on' : '', `Gamepad ${u}`);
        b.type = 'button';
        b.addEventListener('click', () => { this.gp.assign(u, p.index); this.padKey = null; this.paintPadDialog(); this.paintPadButton(); });
        seg.appendChild(b);
      }
      row.appendChild(seg);
      list.appendChild(row);
    }
    this.paintPadLive(pads);
  },
  paintPadLive(pads) {
    for (const p of pads) {
      const live = document.querySelector(`.pad-live[data-index="${p.index}"]`);
      if (!live) continue;
      const pressed = p.buttons.map((b, i) => (b.pressed ? i : -1)).filter(i => i >= 0);
      const names = ['A', 'B', 'X', 'Y', 'LB', 'RB', 'LT', 'RT', 'Back', 'Start', 'L3', 'R3', '↑', '↓', '←', '→', 'Guide'];
      live.textContent = pressed.length ? pressed.map(i => names[i] || '#' + i).join(' ') : `LX ${p.axes[0].toFixed(1)} LY ${p.axes[1].toFixed(1)}`;
    }
  },
});
})(typeof globalThis !== 'undefined' ? globalThis : window);
